import { Heart, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function HeroSection() {
  return (
    <div className="text-center py-8">
      <div className="inline-block animate-bounce">
        <Heart className="h-12 w-12 text-red-500 fill-red-500" />
      </div>
      <h1 className="text-4xl md:text-6xl font-bold text-pink-600 mb-4 font-cursive">True Love Calculator</h1>
      <p className="text-lg md:text-xl text-pink-700 max-w-2xl mx-auto mb-6">
        Discover your love compatibility, future relationship predictions, and fun love insights with our AI-powered
        tools!
      </p>
      <div className="flex flex-wrap gap-4 justify-center">
        <Link href="/">
          <Button size="lg" className="bg-pink-500 hover:bg-pink-600 text-white">
            <Heart className="mr-2 h-4 w-4 fill-white" /> Calculate Love
          </Button>
        </Link>
        <Link href="/tools">
          <Button size="lg" variant="outline" className="border-pink-500 text-pink-600 hover:bg-pink-100">
            <Sparkles className="mr-2 h-4 w-4" /> Explore All Tools
          </Button>
        </Link>
      </div>
    </div>
  )
}

