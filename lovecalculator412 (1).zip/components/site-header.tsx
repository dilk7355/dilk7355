"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Heart, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { ThemeToggle } from "@/components/theme-toggle"

const navigation = [
  { name: "Home", href: "/" },
  { name: "All Tools", href: "/tools" },
  { name: "Zodiac Match", href: "/zodiac-match" },
  { name: "Love Story", href: "/love-story-generator" },
  { name: "About", href: "/about" },
]

export default function SiteHeader() {
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b border-pink-200 bg-white/80 backdrop-blur-sm">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Heart className="h-6 w-6 text-red-500 fill-red-500" />
          <span className="text-xl font-bold text-pink-600 font-cursive">TrueLoveCalculator.fun</span>
        </Link>

        {/* Desktop navigation */}
        <nav className="hidden md:flex items-center gap-6">
          {navigation.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`text-sm font-medium transition-colors hover:text-pink-600 ${
                pathname === item.href ? "text-pink-600" : "text-muted-foreground"
              }`}
            >
              {item.name}
            </Link>
          ))}
          <ThemeToggle />
          <Link href="/">
            <Button className="bg-pink-500 hover:bg-pink-600 text-white">
              <Heart className="mr-2 h-4 w-4 fill-white" /> Calculate Love
            </Button>
          </Link>
        </nav>

        {/* Mobile navigation */}
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon" aria-label="Menu">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[80%] sm:w-[350px] bg-white dark:bg-gray-900">
            <div className="flex flex-col gap-6 py-6">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`text-lg font-medium transition-colors hover:text-pink-600 ${
                    pathname === item.href ? "text-pink-600" : "text-muted-foreground"
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
              <div className="flex items-center">
                <ThemeToggle />
                <span className="ml-2 text-sm text-muted-foreground">Toggle theme</span>
              </div>
              <Link href="/" onClick={() => setIsOpen(false)}>
                <Button className="bg-pink-500 hover:bg-pink-600 text-white mt-4 w-full">
                  <Heart className="mr-2 h-4 w-4 fill-white" /> Calculate Love
                </Button>
              </Link>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}

