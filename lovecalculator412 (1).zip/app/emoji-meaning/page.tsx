"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Smile, Copy, Info, Heart } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

// Emoji categories
const categories = [
  { id: "all", label: "All Emojis" },
  { id: "smileys", label: "Smileys & Emotions" },
  { id: "people", label: "People & Body" },
  { id: "animals", label: "Animals & Nature" },
  { id: "food", label: "Food & Drink" },
  { id: "travel", label: "Travel & Places" },
  { id: "activities", label: "Activities" },
  { id: "objects", label: "Objects" },
  { id: "symbols", label: "Symbols" },
  { id: "flags", label: "Flags" },
]

// Emoji database with meanings
const emojiDatabase = [
  // Smileys & Emotions
  {
    emoji: "😀",
    name: "Grinning Face",
    meaning: "A typical smiley face. Represents happiness and positive feelings.",
    category: "smileys",
  },
  {
    emoji: "😃",
    name: "Grinning Face with Big Eyes",
    meaning: "A happy face with big eyes, showing excitement or enthusiasm.",
    category: "smileys",
  },
  {
    emoji: "😄",
    name: "Grinning Face with Smiling Eyes",
    meaning: "A happy face with smiling eyes, showing joy or delight.",
    category: "smileys",
  },
  {
    emoji: "😁",
    name: "Beaming Face with Smiling Eyes",
    meaning: "A happy face with a big grin and smiling eyes, showing extreme happiness.",
    category: "smileys",
  },
  {
    emoji: "😆",
    name: "Grinning Squinting Face",
    meaning: "A happy face with tightly closed eyes, showing laughter or satisfaction.",
    category: "smileys",
  },
  {
    emoji: "😅",
    name: "Grinning Face with Sweat",
    meaning: "A smiling face with a single drop of sweat, representing relief or close call.",
    category: "smileys",
  },
  {
    emoji: "🤣",
    name: "Rolling on the Floor Laughing",
    meaning: "A face that is laughing so hard that it's rolling on the floor. Shows extreme laughter.",
    category: "smileys",
  },
  {
    emoji: "😂",
    name: "Face with Tears of Joy",
    meaning: "A laughing face with tears, showing uncontrollable laughter.",
    category: "smileys",
  },
  {
    emoji: "🙂",
    name: "Slightly Smiling Face",
    meaning: "A face with a slight smile, showing contentment or mild happiness.",
    category: "smileys",
  },
  {
    emoji: "🙃",
    name: "Upside-Down Face",
    meaning: "A face that is upside down, often used to convey sarcasm, irony, or silliness.",
    category: "smileys",
  },
  {
    emoji: "😉",
    name: "Winking Face",
    meaning: "A face with one eye closed, indicating a joke, flirtation, or hidden meaning.",
    category: "smileys",
  },
  {
    emoji: "😊",
    name: "Smiling Face with Smiling Eyes",
    meaning: "A warm, genuine smile with smiling eyes, showing happiness and warmth.",
    category: "smileys",
  },
  {
    emoji: "😇",
    name: "Smiling Face with Halo",
    meaning: "A smiling face with a halo above it, representing innocence or good deeds.",
    category: "smileys",
  },
  {
    emoji: "😍",
    name: "Smiling Face with Heart-Eyes",
    meaning: "A face with hearts for eyes, showing love, infatuation, or adoration.",
    category: "smileys",
  },
  {
    emoji: "🥰",
    name: "Smiling Face with Hearts",
    meaning: "A smiling face surrounded by hearts, showing affection and love.",
    category: "smileys",
  },
  {
    emoji: "😘",
    name: "Face Blowing a Kiss",
    meaning: "A face blowing a kiss, showing affection or gratitude.",
    category: "smileys",
  },
  {
    emoji: "😗",
    name: "Kissing Face",
    meaning: "A face with puckered lips, ready to give a kiss.",
    category: "smileys",
  },
  {
    emoji: "😙",
    name: "Kissing Face with Smiling Eyes",
    meaning: "A face with puckered lips and smiling eyes, showing affection.",
    category: "smileys",
  },
  {
    emoji: "😚",
    name: "Kissing Face with Closed Eyes",
    meaning: "A face with puckered lips and closed eyes, showing romantic affection.",
    category: "smileys",
  },
  {
    emoji: "🥲",
    name: "Smiling Face with Tear",
    meaning: "A smiling face with a tear, representing gratitude or being touched.",
    category: "smileys",
  },

  // People & Body
  {
    emoji: "👋",
    name: "Waving Hand",
    meaning: "A hand waving, commonly used as a greeting or farewell gesture.",
    category: "people",
  },
  {
    emoji: "🤚",
    name: "Raised Back of Hand",
    meaning: "The back of a hand raised, can be used to signal 'stop' or 'high five'.",
    category: "people",
  },
  {
    emoji: "✋",
    name: "Raised Hand",
    meaning: "A raised hand, can be used to signal 'stop', 'high five', or to get attention.",
    category: "people",
  },
  {
    emoji: "🖐️",
    name: "Hand with Fingers Splayed",
    meaning: "A hand with all fingers spread out, showing openness or a greeting.",
    category: "people",
  },
  {
    emoji: "👌",
    name: "OK Hand",
    meaning: "A hand making the OK sign, indicating approval or agreement.",
    category: "people",
  },
  {
    emoji: "🤌",
    name: "Pinched Fingers",
    meaning: "Fingers pinched together, commonly used in Italian gestures to express confusion or question.",
    category: "people",
  },
  {
    emoji: "🤞",
    name: "Crossed Fingers",
    meaning: "Fingers crossed, indicating hope for good luck or a white lie.",
    category: "people",
  },
  {
    emoji: "🤟",
    name: "Love-You Gesture",
    meaning: "A hand making the ILY (I Love You) sign in American Sign Language.",
    category: "people",
  },
  {
    emoji: "🤘",
    name: "Sign of the Horns",
    meaning: "A hand making the rock on sign, associated with rock music and concerts.",
    category: "people",
  },
  {
    emoji: "👍",
    name: "Thumbs Up",
    meaning: "A thumbs up gesture, indicating approval or agreement.",
    category: "people",
  },

  // Animals & Nature
  {
    emoji: "🐶",
    name: "Dog Face",
    meaning: "The face of a dog, representing loyalty, friendship, or pets.",
    category: "animals",
  },
  {
    emoji: "🐱",
    name: "Cat Face",
    meaning: "The face of a cat, representing independence, pets, or internet culture.",
    category: "animals",
  },
  {
    emoji: "🐭",
    name: "Mouse Face",
    meaning: "The face of a mouse, often associated with shyness or cuteness.",
    category: "animals",
  },
  {
    emoji: "🐹",
    name: "Hamster Face",
    meaning: "The face of a hamster, representing pets or cuteness.",
    category: "animals",
  },
  {
    emoji: "🐰",
    name: "Rabbit Face",
    meaning: "The face of a rabbit, associated with Easter, speed, or cuteness.",
    category: "animals",
  },
  {
    emoji: "🦊",
    name: "Fox Face",
    meaning: "The face of a fox, representing cleverness or cunning.",
    category: "animals",
  },
  {
    emoji: "🐻",
    name: "Bear Face",
    meaning: "The face of a bear, representing strength, wilderness, or cuddliness.",
    category: "animals",
  },
  {
    emoji: "🐼",
    name: "Panda Face",
    meaning: "The face of a panda, representing China, conservation, or cuteness.",
    category: "animals",
  },
  {
    emoji: "🦁",
    name: "Lion Face",
    meaning: "The face of a lion, representing courage, leadership, or royalty.",
    category: "animals",
  },
  {
    emoji: "🐮",
    name: "Cow Face",
    meaning: "The face of a cow, representing farm animals or dairy products.",
    category: "animals",
  },

  // Food & Drink
  {
    emoji: "🍎",
    name: "Red Apple",
    meaning: "A red apple, representing health, education, or temptation.",
    category: "food",
  },
  { emoji: "🍐", name: "Pear", meaning: "A pear fruit, representing healthy eating or sweetness.", category: "food" },
  {
    emoji: "🍊",
    name: "Tangerine",
    meaning: "A tangerine or orange, representing citrus fruits or vitamin C.",
    category: "food",
  },
  {
    emoji: "🍋",
    name: "Lemon",
    meaning: "A lemon, representing sourness, freshness, or cleanliness.",
    category: "food",
  },
  {
    emoji: "🍌",
    name: "Banana",
    meaning: "A banana, representing tropical fruits, potassium, or comedy.",
    category: "food",
  },
  {
    emoji: "🍉",
    name: "Watermelon",
    meaning: "A slice of watermelon, representing summer, refreshment, or sweetness.",
    category: "food",
  },
  {
    emoji: "🍇",
    name: "Grapes",
    meaning: "A bunch of grapes, representing wine, abundance, or fertility.",
    category: "food",
  },
  {
    emoji: "🍓",
    name: "Strawberry",
    meaning: "A strawberry, representing sweetness, summer, or romance.",
    category: "food",
  },
  {
    emoji: "🫐",
    name: "Blueberries",
    meaning: "Blueberries, representing antioxidants, health, or baking.",
    category: "food",
  },
  {
    emoji: "🍒",
    name: "Cherries",
    meaning: "Cherries, representing sweetness, innocence, or gambling.",
    category: "food",
  },

  // Travel & Places
  {
    emoji: "🚗",
    name: "Car",
    meaning: "A car, representing transportation, travel, or commuting.",
    category: "travel",
  },
  {
    emoji: "🚕",
    name: "Taxi",
    meaning: "A taxi cab, representing urban transportation or getting a ride.",
    category: "travel",
  },
  {
    emoji: "🚙",
    name: "Sport Utility Vehicle",
    meaning: "An SUV, representing off-road travel or family vehicles.",
    category: "travel",
  },
  {
    emoji: "🚌",
    name: "Bus",
    meaning: "A bus, representing public transportation or group travel.",
    category: "travel",
  },
  {
    emoji: "🚎",
    name: "Trolleybus",
    meaning: "A trolleybus, representing electric public transportation.",
    category: "travel",
  },
  {
    emoji: "🏎️",
    name: "Racing Car",
    meaning: "A racing car, representing speed, competition, or Formula 1.",
    category: "travel",
  },
  {
    emoji: "🚓",
    name: "Police Car",
    meaning: "A police car, representing law enforcement or emergency services.",
    category: "travel",
  },
  {
    emoji: "🚑",
    name: "Ambulance",
    meaning: "An ambulance, representing emergency medical services or hospitals.",
    category: "travel",
  },
  {
    emoji: "🚒",
    name: "Fire Engine",
    meaning: "A fire engine, representing firefighting or emergency services.",
    category: "travel",
  },
  {
    emoji: "🚐",
    name: "Minibus",
    meaning: "A minibus, representing group transportation or shuttle services.",
    category: "travel",
  },

  // Activities
  {
    emoji: "⚽",
    name: "Soccer Ball",
    meaning: "A soccer ball, representing football/soccer or sports in general.",
    category: "activities",
  },
  {
    emoji: "🏀",
    name: "Basketball",
    meaning: "A basketball, representing basketball or sports in general.",
    category: "activities",
  },
  {
    emoji: "🏈",
    name: "American Football",
    meaning: "An American football, representing American football or sports in general.",
    category: "activities",
  },
  {
    emoji: "⚾",
    name: "Baseball",
    meaning: "A baseball, representing baseball or sports in general.",
    category: "activities",
  },
  {
    emoji: "🥎",
    name: "Softball",
    meaning: "A softball, representing softball or recreational sports.",
    category: "activities",
  },
  {
    emoji: "🎾",
    name: "Tennis",
    meaning: "A tennis ball and racket, representing tennis or racket sports.",
    category: "activities",
  },
  {
    emoji: "🏐",
    name: "Volleyball",
    meaning: "A volleyball, representing volleyball or beach sports.",
    category: "activities",
  },
  {
    emoji: "🏉",
    name: "Rugby Football",
    meaning: "A rugby ball, representing rugby or contact sports.",
    category: "activities",
  },
  {
    emoji: "🥏",
    name: "Flying Disc",
    meaning: "A flying disc, representing frisbee or outdoor games.",
    category: "activities",
  },
  {
    emoji: "🎱",
    name: "Pool 8 Ball",
    meaning: "An 8-ball, representing billiards, pool, or games of chance.",
    category: "activities",
  },

  // Objects
  {
    emoji: "⌚",
    name: "Watch",
    meaning: "A wristwatch, representing time, punctuality, or accessories.",
    category: "objects",
  },
  {
    emoji: "📱",
    name: "Mobile Phone",
    meaning: "A smartphone, representing communication, technology, or social media.",
    category: "objects",
  },
  {
    emoji: "💻",
    name: "Laptop",
    meaning: "A laptop computer, representing work, technology, or remote activities.",
    category: "objects",
  },
  {
    emoji: "⌨️",
    name: "Keyboard",
    meaning: "A computer keyboard, representing typing, coding, or data entry.",
    category: "objects",
  },
  {
    emoji: "🖥️",
    name: "Desktop Computer",
    meaning: "A desktop computer, representing office work or gaming.",
    category: "objects",
  },
  {
    emoji: "🖨️",
    name: "Printer",
    meaning: "A printer, representing document production or office equipment.",
    category: "objects",
  },
  {
    emoji: "🖱️",
    name: "Computer Mouse",
    meaning: "A computer mouse, representing computer use or navigation.",
    category: "objects",
  },
  {
    emoji: "🖲️",
    name: "Trackball",
    meaning: "A trackball, representing alternative computer navigation.",
    category: "objects",
  },
  {
    emoji: "📷",
    name: "Camera",
    meaning: "A camera, representing photography, memories, or social media.",
    category: "objects",
  },
  {
    emoji: "🎥",
    name: "Movie Camera",
    meaning: "A movie camera, representing filmmaking, videos, or entertainment.",
    category: "objects",
  },

  // Symbols
  {
    emoji: "❤️",
    name: "Red Heart",
    meaning: "A red heart, the universal symbol of love, affection, and romance.",
    category: "symbols",
  },
  {
    emoji: "🧡",
    name: "Orange Heart",
    meaning: "An orange heart, representing friendship, enthusiasm, or creativity.",
    category: "symbols",
  },
  {
    emoji: "💛",
    name: "Yellow Heart",
    meaning: "A yellow heart, representing happiness, optimism, or friendship.",
    category: "symbols",
  },
  {
    emoji: "💚",
    name: "Green Heart",
    meaning: "A green heart, representing nature, growth, or jealousy.",
    category: "symbols",
  },
  {
    emoji: "💙",
    name: "Blue Heart",
    meaning: "A blue heart, representing trust, harmony, or peace.",
    category: "symbols",
  },
  {
    emoji: "💜",
    name: "Purple Heart",
    meaning: "A purple heart, representing nobility, spirituality, or ceremony.",
    category: "symbols",
  },
  {
    emoji: "🖤",
    name: "Black Heart",
    meaning: "A black heart, representing grief, dark humor, or rebellion.",
    category: "symbols",
  },
  {
    emoji: "🤍",
    name: "White Heart",
    meaning: "A white heart, representing purity, innocence, or new beginnings.",
    category: "symbols",
  },
  {
    emoji: "🤎",
    name: "Brown Heart",
    meaning: "A brown heart, representing comfort, stability, or earthiness.",
    category: "symbols",
  },
  {
    emoji: "💔",
    name: "Broken Heart",
    meaning: "A broken heart, representing heartbreak, grief, or the end of a relationship.",
    category: "symbols",
  },

  // Flags
  {
    emoji: "🏁",
    name: "Chequered Flag",
    meaning: "A chequered flag, representing the start or finish of a race.",
    category: "flags",
  },
  {
    emoji: "🚩",
    name: "Triangular Flag",
    meaning: "A triangular flag, representing location markers or warnings.",
    category: "flags",
  },
  {
    emoji: "🎌",
    name: "Crossed Flags",
    meaning: "Crossed flags, representing celebration or ceremony, especially in Japan.",
    category: "flags",
  },
  {
    emoji: "🏴",
    name: "Black Flag",
    meaning: "A black flag, representing piracy, anarchy, or mourning.",
    category: "flags",
  },
  {
    emoji: "🏳️",
    name: "White Flag",
    meaning: "A white flag, representing surrender, truce, or peace.",
    category: "flags",
  },
  {
    emoji: "🏳️‍🌈",
    name: "Rainbow Flag",
    meaning: "A rainbow flag, representing LGBTQ+ pride and diversity.",
    category: "flags",
  },
  {
    emoji: "🏳️‍⚧️",
    name: "Transgender Flag",
    meaning: "A transgender flag, representing transgender pride and rights.",
    category: "flags",
  },
  {
    emoji: "🏴‍☠️",
    name: "Pirate Flag",
    meaning: "A pirate flag with skull and crossbones, representing piracy or rebellion.",
    category: "flags",
  },
  {
    emoji: "🇺🇳",
    name: "United Nations Flag",
    meaning: "The flag of the United Nations, representing international cooperation.",
    category: "flags",
  },
  {
    emoji: "🇪🇺",
    name: "European Union Flag",
    meaning: "The flag of the European Union, representing European unity.",
    category: "flags",
  },
]

export default function EmojiMeaningPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState("all")
  const [selectedEmoji, setSelectedEmoji] = useState<(typeof emojiDatabase)[0] | null>(null)
  const [recentEmojis, setRecentEmojis] = useState<string[]>([])
  const { toast } = useToast()

  // Load recent emojis from localStorage on component mount
  useEffect(() => {
    const storedRecents = localStorage.getItem("recentEmojis")
    if (storedRecents) {
      setRecentEmojis(JSON.parse(storedRecents))
    }
  }, [])

  // Filter emojis based on search query and active category
  const filteredEmojis = emojiDatabase.filter((emoji) => {
    const matchesSearch =
      emoji.emoji.includes(searchQuery) ||
      emoji.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      emoji.meaning.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCategory = activeCategory === "all" || emoji.category === activeCategory

    return matchesSearch && matchesCategory
  })

  const handleEmojiClick = (emoji: (typeof emojiDatabase)[0]) => {
    setSelectedEmoji(emoji)

    // Add to recent emojis
    const updatedRecents = [emoji.emoji, ...recentEmojis.filter((e) => e !== emoji.emoji)].slice(0, 10)
    setRecentEmojis(updatedRecents)
    localStorage.setItem("recentEmojis", JSON.stringify(updatedRecents))
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied!",
      description: `"${text}" copied to clipboard`,
    })
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-yellow-200 to-orange-200 dark:from-gray-900 dark:to-gray-800 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-yellow-600 dark:text-yellow-400 mb-6 text-center">
          Emoji Meaning Tool
        </h1>

        <Card className="max-w-4xl mx-auto border-yellow-200 dark:border-gray-700 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-yellow-600 dark:text-yellow-400 flex items-center gap-2">
              <Smile className="h-5 w-5 text-yellow-500" />
              Emoji Meaning Finder
            </CardTitle>
            <CardDescription className="dark:text-gray-300">
              Discover the meaning behind emojis and how to use them correctly
            </CardDescription>

            <div className="mt-4 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search emojis by symbol or keyword..."
                className="pl-9 border-yellow-200 dark:border-gray-600 focus:border-yellow-400 dark:focus:border-yellow-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </CardHeader>

          <CardContent>
            <Tabs defaultValue="all" className="w-full" onValueChange={setActiveCategory} value={activeCategory}>
              <TabsList className="w-full mb-4 flex flex-wrap h-auto bg-yellow-50 dark:bg-gray-700 p-1">
                {categories.map((category) => (
                  <TabsTrigger
                    key={category.id}
                    value={category.id}
                    className="flex-1 min-w-[100px] data-[state=active]:bg-white dark:data-[state=active]:bg-gray-800 data-[state=active]:text-yellow-600 dark:data-[state=active]:text-yellow-400"
                  >
                    {category.label}
                  </TabsTrigger>
                ))}
              </TabsList>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  {recentEmojis.length > 0 && (
                    <div className="mb-4">
                      <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Recently Viewed</h3>
                      <div className="flex flex-wrap gap-2 p-2 bg-gray-50 dark:bg-gray-700 rounded-md">
                        {recentEmojis.map((emoji) => {
                          const emojiData = emojiDatabase.find((e) => e.emoji === emoji)
                          return (
                            <button
                              key={emoji}
                              onClick={() => emojiData && handleEmojiClick(emojiData)}
                              className="text-2xl hover:bg-yellow-100 dark:hover:bg-gray-600 p-1 rounded"
                              title={emojiData?.name || ""}
                            >
                              {emoji}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  )}

                  <div className="h-[400px] overflow-y-auto border rounded-md p-2 bg-white dark:bg-gray-800 dark:border-gray-700">
                    <div className="grid grid-cols-8 sm:grid-cols-10 gap-1">
                      {filteredEmojis.map((emoji) => (
                        <button
                          key={emoji.emoji}
                          onClick={() => handleEmojiClick(emoji)}
                          className={`text-2xl hover:bg-yellow-100 dark:hover:bg-gray-700 p-1 rounded ${
                            selectedEmoji?.emoji === emoji.emoji ? "bg-yellow-200 dark:bg-yellow-900" : ""
                          }`}
                          title={emoji.name}
                        >
                          {emoji.emoji}
                        </button>
                      ))}
                    </div>

                    {filteredEmojis.length === 0 && (
                      <div className="flex flex-col items-center justify-center h-full text-gray-500 dark:text-gray-400">
                        <Smile className="h-12 w-12 mb-2 opacity-20" />
                        <p>No emojis found matching your search.</p>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  {selectedEmoji ? (
                    <div className="bg-yellow-50 dark:bg-gray-700 p-4 rounded-lg border border-yellow-200 dark:border-gray-600 h-full">
                      <div className="flex justify-between items-start mb-4">
                        <div className="text-6xl">{selectedEmoji.emoji}</div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(selectedEmoji.emoji)}
                          className="text-yellow-600 dark:text-yellow-400 hover:text-yellow-700 dark:hover:text-yellow-300"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>

                      <h3 className="text-xl font-bold text-yellow-600 dark:text-yellow-400 mb-2">
                        {selectedEmoji.name}
                      </h3>

                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Meaning</h4>
                          <p className="text-gray-700 dark:text-gray-300">{selectedEmoji.meaning}</p>
                        </div>

                        <div>
                          <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Category</h4>
                          <p className="text-gray-700 dark:text-gray-300 capitalize">{selectedEmoji.category}</p>
                        </div>

                        <div>
                          <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Usage Tips</h4>
                          <p className="text-gray-700 dark:text-gray-300">
                            Use this emoji in contexts related to {selectedEmoji.meaning.toLowerCase().split(".")[0]}.
                          </p>
                        </div>

                        <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mt-4">
                          <Info className="h-4 w-4" />
                          <p>Emoji appearances may vary across different platforms</p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-yellow-50 dark:bg-gray-700 p-4 rounded-lg border border-yellow-200 dark:border-gray-600 h-full flex flex-col items-center justify-center text-center">
                      <Smile className="h-16 w-16 text-yellow-300 dark:text-yellow-500 mb-4" />
                      <h3 className="text-lg font-medium text-yellow-600 dark:text-yellow-400 mb-2">Select an emoji</h3>
                      <p className="text-gray-500 dark:text-gray-400">
                        Click on any emoji to see its meaning and usage
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </Tabs>
          </CardContent>

          <CardFooter className="flex justify-center border-t border-yellow-100 dark:border-gray-700 pt-4">
            <div className="text-sm text-gray-500 dark:text-gray-400 max-w-md text-center">
              <p>
                <Heart className="h-4 w-4 inline-block mr-1 text-red-500" />
                Emoji meanings may vary by context and culture. This tool provides general interpretations.
              </p>
            </div>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}

