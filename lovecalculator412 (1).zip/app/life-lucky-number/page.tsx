"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Calculator, Sparkles, Star, Heart } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

type NumberMeaning = {
  number: number
  meaning: string
  traits: string[]
  loveCompatibility: string
}

export default function LifeLuckyNumberPage() {
  const [name, setName] = useState("")
  const [birthdate, setBirthdate] = useState("")
  const [result, setResult] = useState<null | {
    luckyNumber: number
    meaning: string
    traits: string[]
    loveCompatibility: string
  }>(null)
  const [isCalculating, setIsCalculating] = useState(false)
  const { toast } = useToast()

  // Number meanings and traits
  const numberMeanings: NumberMeaning[] = [
    {
      number: 1,
      meaning: "The Leader",
      traits: ["Independent", "Original", "Creative", "Ambitious", "Strong-willed"],
      loveCompatibility: "Most compatible with 3, 5, and 6. May challenge with 8 and 9.",
    },
    {
      number: 2,
      meaning: "The Peacemaker",
      traits: ["Diplomatic", "Sensitive", "Cooperative", "Intuitive", "Supportive"],
      loveCompatibility: "Most compatible with 4, 6, and 8. May need patience with 1 and 7.",
    },
    {
      number: 3,
      meaning: "The Expressive One",
      traits: ["Creative", "Social", "Optimistic", "Inspiring", "Communicative"],
      loveCompatibility: "Most compatible with 1, 5, and 7. May need balance with 4 and 8.",
    },
    {
      number: 4,
      meaning: "The Builder",
      traits: ["Practical", "Reliable", "Disciplined", "Hardworking", "Loyal"],
      loveCompatibility: "Most compatible with 2, 6, and 8. May need flexibility with 3 and 7.",
    },
    {
      number: 5,
      meaning: "The Freedom Seeker",
      traits: ["Adaptable", "Versatile", "Adventurous", "Curious", "Progressive"],
      loveCompatibility: "Most compatible with 1, 3, and 7. May need stability with 4 and 8.",
    },
    {
      number: 6,
      meaning: "The Nurturer",
      traits: ["Loving", "Responsible", "Caring", "Protective", "Harmonious"],
      loveCompatibility: "Most compatible with 1, 2, and 9. May need independence with 5 and 7.",
    },
    {
      number: 7,
      meaning: "The Seeker",
      traits: ["Analytical", "Introspective", "Perfectionist", "Spiritual", "Wise"],
      loveCompatibility: "Most compatible with 3, 5, and 9. May need openness with 2 and 6.",
    },
    {
      number: 8,
      meaning: "The Achiever",
      traits: ["Ambitious", "Powerful", "Successful", "Authoritative", "Abundant"],
      loveCompatibility: "Most compatible with 2, 4, and 6. May need softness with 1 and 3.",
    },
    {
      number: 9,
      meaning: "The Humanitarian",
      traits: ["Compassionate", "Generous", "Selfless", "Idealistic", "Artistic"],
      loveCompatibility: "Most compatible with 3, 6, and 9. May need practicality with 2 and 5.",
    },
  ]

  const calculateLuckyNumber = () => {
    if (!birthdate) {
      toast({
        title: "Birthdate required",
        description: "Please enter your date of birth to calculate your life lucky number",
        variant: "destructive",
      })
      return
    }

    setIsCalculating(true)
    setTimeout(() => {
      // Parse the birthdate
      const birthdateObj = new Date(birthdate)
      const day = birthdateObj.getDate()
      const month = birthdateObj.getMonth() + 1 // Months are 0-indexed
      const year = birthdateObj.getFullYear()

      // Calculate life path number by adding all digits together
      let sum = day + month + Array.from(String(year), Number).reduce((a, b) => a + b, 0)

      // Reduce to a single digit (1-9), except for master numbers 11, 22, 33
      while (sum > 9 && sum !== 11 && sum !== 22 && sum !== 33) {
        sum = Array.from(String(sum), Number).reduce((a, b) => a + b, 0)
      }

      // Handle master numbers for simplicity in this app
      if (sum === 11 || sum === 22 || sum === 33) {
        sum = Array.from(String(sum), Number).reduce((a, b) => a + b, 0)
      }

      // Get meaning for this number
      const numberInfo = numberMeanings.find((item) => item.number === sum) || numberMeanings[0]

      setResult({
        luckyNumber: sum,
        meaning: numberInfo.meaning,
        traits: numberInfo.traits,
        loveCompatibility: numberInfo.loveCompatibility,
      })

      setIsCalculating(false)
    }, 1500)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-purple-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-purple-600 mb-6 text-center">Life Lucky Number</h1>

        <Card className="max-w-md mx-auto border-purple-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-purple-600 flex items-center justify-center gap-2">
              <Calculator className="h-5 w-5 text-purple-500" />
              Life Lucky Number Calculator
            </CardTitle>
            <CardDescription>Discover your life path number and its meaning in love</CardDescription>
          </CardHeader>

          <CardContent>
            {!result ? (
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Your Name (Optional)</Label>
                  <Input
                    id="name"
                    placeholder="Enter your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="border-purple-200 focus:border-purple-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="birthdate">Your Date of Birth</Label>
                  <Input
                    id="birthdate"
                    type="date"
                    value={birthdate}
                    onChange={(e) => setBirthdate(e.target.value)}
                    className="border-purple-200 focus:border-purple-400"
                    required
                  />
                </div>
              </div>
            ) : (
              <div className="py-6 text-center space-y-6">
                <div className="relative mx-auto w-32 h-32 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-purple-100 animate-pulse"></div>
                  <div className="relative z-10">
                    <div className="text-5xl font-bold text-purple-600">{result.luckyNumber}</div>
                    <div className="text-sm text-purple-500 mt-1">{result.meaning}</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-purple-50 p-4 rounded-lg border border-purple-200 text-left">
                    <div className="flex items-start gap-2">
                      <Star className="h-5 w-5 text-purple-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-purple-700">Your Key Traits:</p>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {result.traits.map((trait, index) => (
                            <span
                              key={index}
                              className="bg-purple-100 text-purple-600 px-2 py-1 rounded-full text-xs font-medium"
                            >
                              {trait}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-pink-50 p-4 rounded-lg border border-pink-200 text-left">
                    <div className="flex items-start gap-2">
                      <Heart className="h-5 w-5 text-pink-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-pink-700">Love Compatibility:</p>
                        <p className="text-pink-600 mt-1">{result.loveCompatibility}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {name && (
                  <div className="text-purple-600 font-medium">
                    <Sparkles className="h-4 w-4 inline-block mr-1" />
                    {name}, your life path number reveals your natural strengths and potential challenges in love.
                  </div>
                )}
              </div>
            )}
          </CardContent>

          <CardFooter>
            <Button
              onClick={result ? () => setResult(null) : calculateLuckyNumber}
              className={`w-full ${
                !result
                  ? "bg-purple-500 hover:bg-purple-600 text-white"
                  : "bg-purple-100 hover:bg-purple-200 text-purple-600"
              }`}
              disabled={isCalculating}
            >
              {isCalculating ? (
                <>
                  Calculating your number<span className="animate-pulse">...</span>
                </>
              ) : result ? (
                <>Calculate Again</>
              ) : (
                <>Reveal My Lucky Number</>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}

