"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Clock, Calendar, Heart } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

export default function RelationshipExpiryPage() {
  const [yourName, setYourName] = useState("")
  const [partnerName, setPartnerName] = useState("")
  const [relationshipType, setRelationshipType] = useState("dating")
  const [result, setResult] = useState<null | {
    expiryDate: string
    daysLeft: number
    percentage: number
    reason: string
    advice: string
  }>(null)
  const [isCalculating, setIsCalculating] = useState(false)
  const { toast } = useToast()

  // Possible reasons for relationship expiry
  const expiryReasons = {
    dating: [
      "Different life goals becoming apparent",
      "Communication challenges emerging",
      "Growing apart due to changing interests",
      "Trust issues developing over time",
      "External pressures from work or family",
    ],
    serious: [
      "Unresolved conflicts accumulating",
      "Different views on commitment and future",
      "Emotional connection fading",
      "Lifestyle incompatibilities becoming significant",
      "Personal growth in different directions",
    ],
    married: [
      "Financial disagreements creating tension",
      "Different parenting philosophies",
      "Intimacy and connection challenges",
      "Career paths creating distance",
      "Unmet expectations building resentment",
    ],
  }

  // Advice for extending relationship
  const relationshipAdvice = {
    dating: [
      "Schedule regular date nights to maintain connection",
      "Practice active listening to improve communication",
      "Explore new activities together to create shared experiences",
      "Discuss expectations openly to avoid misunderstandings",
      "Give each other space to maintain individuality",
    ],
    serious: [
      "Consider relationship counseling to address recurring issues",
      "Develop conflict resolution strategies together",
      "Discuss long-term goals to ensure alignment",
      "Create rituals that strengthen your bond",
      "Make time for meaningful conversations beyond daily logistics",
    ],
    married: [
      "Schedule regular check-ins about your relationship health",
      "Seek marriage counseling before small issues become big problems",
      "Maintain individual interests while creating shared goals",
      "Practice gratitude and appreciation daily",
      "Prioritize intimacy and connection despite busy schedules",
    ],
  }

  const calculateExpiry = () => {
    if (!yourName || !partnerName) {
      toast({
        title: "Names required",
        description: "Please enter both names to calculate relationship expiry",
        variant: "destructive",
      })
      return
    }

    setIsCalculating(true)

    // Simulate calculation with timeout
    setTimeout(() => {
      // Generate a "random" but deterministic result based on names and relationship type
      const combinedNames = (yourName + partnerName).toLowerCase()
      let sum = 0

      for (let i = 0; i < combinedNames.length; i++) {
        sum += combinedNames.charCodeAt(i)
      }

      // Adjust based on relationship type
      let multiplier = 1
      if (relationshipType === "serious") multiplier = 1.5
      if (relationshipType === "married") multiplier = 2.5

      // Calculate days until expiry (between 30 days and 10 years)
      const minDays = 30
      const maxDays = 3650 // 10 years
      let daysLeft = (sum % (maxDays - minDays)) + minDays
      daysLeft = Math.floor(daysLeft * multiplier)

      // Calculate expiry date
      const today = new Date()
      const expiryDate = new Date(today)
      expiryDate.setDate(today.getDate() + daysLeft)

      // Format date
      const formattedDate = expiryDate.toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      })

      // Calculate percentage of relationship completed (assuming max length is 10 years)
      const maxRelationshipDays = 3650 // 10 years
      const percentage = Math.min(100, Math.round((daysLeft / maxRelationshipDays) * 100))

      // Select reason and advice based on relationship type
      const reasonIndex = sum % expiryReasons[relationshipType as keyof typeof expiryReasons].length
      const adviceIndex = (sum + 3) % relationshipAdvice[relationshipType as keyof typeof relationshipAdvice].length

      const reason = expiryReasons[relationshipType as keyof typeof expiryReasons][reasonIndex]
      const advice = relationshipAdvice[relationshipType as keyof typeof relationshipAdvice][adviceIndex]

      setResult({
        expiryDate: formattedDate,
        daysLeft,
        percentage,
        reason,
        advice,
      })

      setIsCalculating(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-blue-600 mb-6 text-center">Relationship Expiry</h1>

        <Card className="max-w-md mx-auto border-blue-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-blue-600 flex items-center justify-center gap-2">
              <Clock className="h-5 w-5 text-blue-500" />
              Relationship Expiry Calculator
            </CardTitle>
            <CardDescription>Find out how long your love will last (for fun only!)</CardDescription>
          </CardHeader>

          <CardContent>
            {!result ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="yourName">Your Name</Label>
                  <Input
                    id="yourName"
                    placeholder="Enter your name"
                    value={yourName}
                    onChange={(e) => setYourName(e.target.value)}
                    className="border-blue-200 focus:border-blue-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="partnerName">Partner's Name</Label>
                  <Input
                    id="partnerName"
                    placeholder="Enter your partner's name"
                    value={partnerName}
                    onChange={(e) => setPartnerName(e.target.value)}
                    className="border-blue-200 focus:border-blue-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="relationshipType">Relationship Type</Label>
                  <Select value={relationshipType} onValueChange={setRelationshipType}>
                    <SelectTrigger id="relationshipType" className="border-blue-200 focus:border-blue-400">
                      <SelectValue placeholder="Select relationship type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dating">Dating / New Relationship</SelectItem>
                      <SelectItem value="serious">Serious Relationship</SelectItem>
                      <SelectItem value="married">Married / Long-term</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            ) : (
              <div className="py-4 space-y-6">
                <div className="text-center">
                  <p className="text-lg font-medium text-blue-600 mb-2">Your Relationship Will Expire On:</p>
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                    <p className="text-xl font-bold text-blue-700">{result.expiryDate}</p>
                    <p className="text-sm text-blue-600 mt-1">({result.daysLeft} days from now)</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-medium text-blue-600 flex justify-between">
                    <span>Relationship Progress</span>
                    <span>{result.percentage}% remaining</span>
                  </p>
                  <Progress value={result.percentage} className="h-2" />
                </div>

                <div className="space-y-4">
                  <div className="bg-pink-50 p-4 rounded-lg border border-pink-200">
                    <div className="flex items-start gap-2">
                      <Clock className="h-5 w-5 text-pink-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-pink-700">Potential Expiry Reason:</p>
                        <p className="text-pink-600 mt-1">{result.reason}</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <div className="flex items-start gap-2">
                      <Heart className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-blue-700">How to Extend Your Relationship:</p>
                        <p className="text-blue-600 mt-1">{result.advice}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>

          <CardFooter>
            <Button
              onClick={result ? () => setResult(null) : calculateExpiry}
              className={`w-full ${
                !result ? "bg-blue-500 hover:bg-blue-600 text-white" : "bg-blue-100 hover:bg-blue-200 text-blue-600"
              }`}
              disabled={isCalculating}
            >
              {isCalculating ? (
                <>
                  Calculating expiry<span className="animate-pulse">...</span>
                </>
              ) : result ? (
                <>Calculate Again</>
              ) : (
                <>Calculate Relationship Expiry</>
              )}
            </Button>
          </CardFooter>
        </Card>

        <div className="max-w-md mx-auto mt-4 text-center text-sm text-blue-600 bg-blue-50 p-3 rounded-lg border border-blue-200">
          <p>
            <Calendar className="h-4 w-4 inline-block mr-1" />
            <strong>Disclaimer:</strong> This tool is for entertainment purposes only. Real relationships require
            communication, trust, and effort!
          </p>
        </div>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}

