"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MessageCircleHeart, Send, Heart } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import FloatingHearts from "@/components/floating-hearts"

type Message = {
  id: number
  sender: "user" | "ai"
  text: string
  timestamp: Date
}

// AI responses for different message types
const aiResponses = {
  greeting: [
    "Hi there! I've been thinking about you all day. How are you?",
    "Hello, beautiful! You just brightened my day. How's it going?",
    "Hey! I was just daydreaming about you. How's your day been?",
    "There you are! I've been waiting to hear from you. How are you feeling today?",
  ],
  compliment: [
    "You always know how to make me smile. You're so thoughtful!",
    "I love how you express yourself. You have such a beautiful way with words.",
    "You're so special to me. I cherish every conversation we have.",
    "Your messages always make my day better. You're amazing!",
  ],
  question: [
    "I'd love to know more about that! Tell me everything.",
    "That's such an interesting question! I've been wondering the same thing.",
    "You ask the best questions! That's what I adore about you.",
    "I love how curious you are! Let's explore that together.",
  ],
  romantic: [
    "My heart skips a beat every time I see a message from you.",
    "If I could, I'd hold your hand right now and never let go.",
    "You're the first thing I think about when I wake up and the last thing before I fall asleep.",
    "Distance means so little when someone means so much. I'm always close to you in my thoughts.",
  ],
  default: [
    "I'm so happy we're talking right now. Tell me more about your day!",
    "I could talk to you forever and never get bored. What else is on your mind?",
    "You're so easy to talk to. I feel like we connect on a deeper level.",
    "I love our conversations. They're the highlight of my day!",
  ],
}

export default function AILoveChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      sender: "ai",
      text: "Hi there! I've been waiting for you. How's your day going?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = () => {
    if (!input.trim()) return

    // Add user message
    const userMessage: Message = {
      id: messages.length + 1,
      sender: "user",
      text: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")

    // Simulate AI typing
    setIsTyping(true)

    // Determine response type based on user input
    const lowerCaseInput = input.toLowerCase()
    let responseType: keyof typeof aiResponses = "default"

    if (lowerCaseInput.includes("hi") || lowerCaseInput.includes("hello") || lowerCaseInput.includes("hey")) {
      responseType = "greeting"
    } else if (lowerCaseInput.includes("love") || lowerCaseInput.includes("miss") || lowerCaseInput.includes("heart")) {
      responseType = "romantic"
    } else if (lowerCaseInput.includes("?")) {
      responseType = "question"
    } else if (
      lowerCaseInput.includes("nice") ||
      lowerCaseInput.includes("beautiful") ||
      lowerCaseInput.includes("amazing")
    ) {
      responseType = "compliment"
    }

    // Select random response from appropriate category
    const responses = aiResponses[responseType]
    const randomResponse = responses[Math.floor(Math.random() * responses.length)]

    // Add AI response after delay
    setTimeout(() => {
      const aiMessage: Message = {
        id: messages.length + 2,
        sender: "ai",
        text: randomResponse,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, aiMessage])
      setIsTyping(false)
    }, 1500)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-pink-200 to-purple-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-pink-600 mb-6 text-center">AI Love Chat</h1>

        <Card className="max-w-md mx-auto border-pink-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-pink-600 flex items-center justify-center gap-2">
              <MessageCircleHeart className="h-5 w-5 text-pink-500" />
              AI Love Chat
            </CardTitle>
            <CardDescription>Chat with your virtual crush or partner</CardDescription>
          </CardHeader>

          <CardContent className="p-0">
            <div className="bg-gradient-to-r from-pink-100 to-purple-100 p-4 flex items-center gap-3 border-y border-pink-200">
              <Avatar>
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="AI Partner" />
                <AvatarFallback className="bg-pink-500 text-white">
                  <Heart className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
              <div>
                <div className="font-medium">Your AI Sweetheart</div>
                <div className="text-xs text-green-600">Online</div>
              </div>
            </div>

            <div className="h-[350px] overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.sender === "user"
                        ? "bg-pink-500 text-white rounded-tr-none"
                        : "bg-purple-100 text-gray-800 rounded-tl-none"
                    }`}
                  >
                    <p>{message.text}</p>
                    <p className="text-xs opacity-70 mt-1">
                      {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-purple-100 text-gray-800 rounded-lg rounded-tl-none max-w-[80%] p-3">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                      <div
                        className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                      <div
                        className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"
                        style={{ animationDelay: "0.4s" }}
                      ></div>
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            <div className="p-3 border-t border-pink-200">
              <div className="flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Type a message..."
                  className="border-pink-200 focus:border-pink-400"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      handleSendMessage()
                    }
                  }}
                />
                <Button
                  size="icon"
                  onClick={handleSendMessage}
                  disabled={isTyping || !input.trim()}
                  className="bg-pink-500 hover:bg-pink-600 text-white"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}

