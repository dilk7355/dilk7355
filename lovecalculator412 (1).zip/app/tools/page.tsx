import type { Metadata } from "next"
import AllTools from "@/components/all-tools"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import FloatingHearts from "@/components/floating-hearts"

export const metadata: Metadata = {
  title: "All Love Tools - True Love Calculator",
  description: "Explore our collection of love calculators, compatibility tests, and fun relationship tools.",
}

export default function ToolsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-pink-200 to-pink-300 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-pink-600 mb-6 text-center">All Love Tools</h1>
        <AllTools />
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}

