"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, Sparkles } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

const zodiacSigns = [
  { value: "aries", label: "Aries (Mar 21 - Apr 19)" },
  { value: "taurus", label: "Taurus (Apr 20 - May 20)" },
  { value: "gemini", label: "Gemini (May 21 - Jun 20)" },
  { value: "cancer", label: "Cancer (Jun 21 - Jul 22)" },
  { value: "leo", label: "Leo (Jul 23 - Aug 22)" },
  { value: "virgo", label: "Virgo (Aug 23 - Sep 22)" },
  { value: "libra", label: "Libra (Sep 23 - Oct 22)" },
  { value: "scorpio", label: "Scorpio (Oct 23 - Nov 21)" },
  { value: "sagittarius", label: "Sagittarius (Nov 22 - Dec 21)" },
  { value: "capricorn", label: "Capricorn (Dec 22 - Jan 19)" },
  { value: "aquarius", label: "Aquarius (Jan 20 - Feb 18)" },
  { value: "pisces", label: "Pisces (Feb 19 - Mar 20)" },
]

// Compatibility data for each zodiac pair
const compatibilityData: Record<string, Record<string, { score: number; description: string }>> = {
  aries: {
    aries: {
      score: 70,
      description: "Two Aries can create a passionate and exciting relationship, but may struggle with power dynamics.",
    },
    taurus: {
      score: 55,
      description:
        "Aries and Taurus can clash due to different approaches to life, but can learn from each other's strengths.",
    },
    gemini: {
      score: 85,
      description:
        "Aries and Gemini share a love for adventure and stimulating conversation, creating a dynamic partnership.",
    },
    cancer: {
      score: 60,
      description:
        "Aries' boldness and Cancer's sensitivity can create challenges, but also a beautifully balanced relationship.",
    },
    leo: { score: 90, description: "Aries and Leo form a fiery, passionate match with mutual respect and admiration." },
    virgo: {
      score: 45,
      description:
        "Aries' impulsiveness and Virgo's methodical nature can create friction, but also complement each other.",
    },
    libra: {
      score: 75,
      description: "Aries and Libra are opposite signs that can create a balanced and harmonious relationship.",
    },
    scorpio: {
      score: 80,
      description:
        "Aries and Scorpio share intensity and passion, creating a powerful but potentially volatile connection.",
    },
    sagittarius: {
      score: 95,
      description:
        "Aries and Sagittarius share a love for adventure and independence, making for an exciting partnership.",
    },
    capricorn: {
      score: 50,
      description:
        "Aries' spontaneity and Capricorn's practicality can clash, but they can build a strong foundation together.",
    },
    aquarius: {
      score: 65,
      description:
        "Aries and Aquarius both value independence and can form an intellectually stimulating relationship.",
    },
    pisces: {
      score: 60,
      description:
        "Aries' directness and Pisces' sensitivity can create challenges, but also a deeply emotional connection.",
    },
  },
  taurus: {
    aries: {
      score: 55,
      description:
        "Taurus and Aries have different approaches to life, but can create a balanced relationship with effort.",
    },
    taurus: {
      score: 90,
      description:
        "Two Taurus partners enjoy stability, loyalty, and sensual pleasures together, creating a secure bond.",
    },
    gemini: {
      score: 45,
      description: "Taurus' need for stability and Gemini's desire for variety can create challenges in this pairing.",
    },
    cancer: {
      score: 95,
      description:
        "Taurus and Cancer share values of security and comfort, creating a nurturing and stable relationship.",
    },
    leo: {
      score: 70,
      description: "Taurus and Leo both appreciate luxury and comfort, but may struggle with stubbornness and pride.",
    },
    virgo: {
      score: 85,
      description: "Taurus and Virgo share practical values and an appreciation for the finer things in life.",
    },
    libra: {
      score: 75,
      description:
        "Taurus and Libra both value beauty and harmony, creating a potentially luxurious and balanced relationship.",
    },
    scorpio: {
      score: 90,
      description: "Taurus and Scorpio are opposite signs with a powerful attraction and deep loyalty to each other.",
    },
    sagittarius: {
      score: 40,
      description: "Taurus' desire for stability and Sagittarius' need for freedom can create fundamental challenges.",
    },
    capricorn: {
      score: 95,
      description:
        "Taurus and Capricorn share practical values and work ethic, creating a stable and supportive partnership.",
    },
    aquarius: {
      score: 35,
      description:
        "Taurus' traditional values and Aquarius' unconventional approach can create significant differences.",
    },
    pisces: {
      score: 80,
      description: "Taurus provides stability for dreamy Pisces, while Pisces brings imagination to practical Taurus.",
    },
  },
  gemini: {
    aries: {
      score: 85,
      description:
        "Gemini and Aries share a love for new experiences and stimulating conversation, creating excitement.",
    },
    taurus: {
      score: 45,
      description: "Gemini's need for variety and Taurus' desire for stability can create fundamental differences.",
    },
    gemini: {
      score: 75,
      description: "Two Geminis create an intellectually stimulating relationship full of communication and variety.",
    },
    cancer: {
      score: 50,
      description: "Gemini's intellectual approach and Cancer's emotional nature can create communication challenges.",
    },
    leo: {
      score: 80,
      description:
        "Gemini and Leo enjoy socializing and entertainment together, creating a fun and dynamic relationship.",
    },
    virgo: {
      score: 70,
      description:
        "Both ruled by Mercury, Gemini and Virgo share intellectual interests but approach life differently.",
    },
    libra: {
      score: 90,
      description:
        "Gemini and Libra share a love for social interaction and intellectual conversation, creating harmony.",
    },
    scorpio: {
      score: 45,
      description: "Gemini's light approach and Scorpio's intensity can create challenges in understanding each other.",
    },
    sagittarius: {
      score: 85,
      description: "Gemini and Sagittarius share a love for freedom, adventure, and philosophical discussions.",
    },
    capricorn: {
      score: 40,
      description: "Gemini's playful nature and Capricorn's serious approach can create significant differences.",
    },
    aquarius: {
      score: 95,
      description: "Gemini and Aquarius share intellectual curiosity and value independence, creating an ideal match.",
    },
    pisces: {
      score: 55,
      description:
        "Gemini's rationality and Pisces' emotionality can create challenges, but also a balanced partnership.",
    },
  },
  cancer: {
    aries: {
      score: 60,
      description:
        "Cancer's sensitivity and Aries' boldness can create challenges, but also a complementary relationship.",
    },
    taurus: {
      score: 95,
      description: "Cancer and Taurus share values of security and comfort, creating a nurturing and stable bond.",
    },
    gemini: {
      score: 50,
      description: "Cancer's emotional depth and Gemini's intellectual approach can create communication challenges.",
    },
    cancer: {
      score: 85,
      description:
        "Two Cancers create a deeply emotional, nurturing, and secure relationship with strong intuitive understanding.",
    },
    leo: {
      score: 65,
      description: "Cancer's need for security and Leo's desire for admiration can create both challenges and balance.",
    },
    virgo: {
      score: 80,
      description:
        "Cancer and Virgo share a desire to nurture and serve, creating a supportive and practical partnership.",
    },
    libra: {
      score: 60,
      description: "Cancer's emotional nature and Libra's rational approach can create both challenges and balance.",
    },
    scorpio: {
      score: 95,
      description: "Cancer and Scorpio share emotional depth and intuition, creating a powerful emotional connection.",
    },
    sagittarius: {
      score: 40,
      description: "Cancer's need for security and Sagittarius' desire for freedom can create fundamental challenges.",
    },
    capricorn: {
      score: 85,
      description:
        "Cancer and Capricorn are opposite signs that can create a balanced relationship of nurturing and ambition.",
    },
    aquarius: {
      score: 45,
      description:
        "Cancer's emotional approach and Aquarius' intellectual detachment can create significant differences.",
    },
    pisces: {
      score: 90,
      description: "Cancer and Pisces share emotional depth and intuition, creating a deeply sympathetic connection.",
    },
  },
  leo: {
    aries: {
      score: 90,
      description:
        "Leo and Aries share passion, creativity, and a zest for life, creating an exciting and dynamic bond.",
    },
    taurus: {
      score: 70,
      description: "Leo and Taurus both appreciate luxury and comfort, but may struggle with stubbornness.",
    },
    gemini: {
      score: 80,
      description: "Leo and Gemini enjoy socializing and entertainment, creating a fun and stimulating relationship.",
    },
    cancer: {
      score: 65,
      description: "Leo's need for admiration and Cancer's desire for security can create both challenges and balance.",
    },
    leo: {
      score: 75,
      description:
        "Two Leos create a relationship full of passion, drama, and mutual admiration, though ego clashes may occur.",
    },
    virgo: {
      score: 55,
      description:
        "Leo's dramatic nature and Virgo's practical approach can create challenges in understanding each other.",
    },
    libra: {
      score: 90,
      description:
        "Leo and Libra share a love for beauty, harmony, and social activities, creating a balanced partnership.",
    },
    scorpio: {
      score: 70,
      description:
        "Leo and Scorpio both have strong wills and passion, creating an intense but potentially challenging match.",
    },
    sagittarius: {
      score: 85,
      description: "Leo and Sagittarius share optimism and enthusiasm for life, creating an adventurous partnership.",
    },
    capricorn: {
      score: 50,
      description: "Leo's expressive nature and Capricorn's reserved approach can create significant differences.",
    },
    aquarius: {
      score: 65,
      description:
        "Leo and Aquarius are opposite signs that can create a balanced relationship of warmth and innovation.",
    },
    pisces: {
      score: 60,
      description:
        "Leo's confidence and Pisces' sensitivity can create both challenges and a complementary relationship.",
    },
  },
  virgo: {
    aries: {
      score: 45,
      description:
        "Virgo's methodical nature and Aries' impulsiveness can create friction, but also complement each other.",
    },
    taurus: {
      score: 85,
      description: "Virgo and Taurus share practical values and an appreciation for quality and detail.",
    },
    gemini: {
      score: 70,
      description:
        "Both ruled by Mercury, Virgo and Gemini share intellectual interests but approach life differently.",
    },
    cancer: {
      score: 80,
      description:
        "Virgo and Cancer share a desire to nurture and serve, creating a supportive and practical partnership.",
    },
    leo: {
      score: 55,
      description:
        "Virgo's practical nature and Leo's dramatic approach can create challenges in understanding each other.",
    },
    virgo: {
      score: 75,
      description:
        "Two Virgos create a relationship based on mutual understanding, practicality, and attention to detail.",
    },
    libra: {
      score: 65,
      description: "Virgo's practicality and Libra's idealism can create both challenges and a balanced partnership.",
    },
    scorpio: {
      score: 85,
      description:
        "Virgo and Scorpio share analytical minds and depth, creating a potentially transformative relationship.",
    },
    sagittarius: {
      score: 40,
      description: "Virgo's need for order and Sagittarius' desire for freedom can create fundamental challenges.",
    },
    capricorn: {
      score: 95,
      description: "Virgo and Capricorn share practical values, work ethic, and ambition, creating an ideal match.",
    },
    aquarius: {
      score: 50,
      description:
        "Virgo's traditional approach and Aquarius' unconventional nature can create significant differences.",
    },
    pisces: {
      score: 75,
      description:
        "Virgo and Pisces are opposite signs that can create a balanced relationship of practicality and imagination.",
    },
  },
  libra: {
    aries: {
      score: 75,
      description: "Libra and Aries are opposite signs that can create a balanced and harmonious relationship.",
    },
    taurus: {
      score: 75,
      description: "Libra and Taurus both value beauty and harmony, creating a potentially luxurious relationship.",
    },
    gemini: {
      score: 90,
      description:
        "Libra and Gemini share a love for social interaction and intellectual conversation, creating harmony.",
    },
    cancer: {
      score: 60,
      description: "Libra's rational nature and Cancer's emotional approach can create both challenges and balance.",
    },
    leo: {
      score: 90,
      description:
        "Libra and Leo share a love for beauty, harmony, and social activities, creating a balanced partnership.",
    },
    virgo: {
      score: 65,
      description: "Libra's idealism and Virgo's practicality can create both challenges and a balanced relationship.",
    },
    libra: {
      score: 80,
      description:
        "Two Libras create a relationship full of harmony, beauty, and social connection, though decision-making may be difficult.",
    },
    scorpio: {
      score: 60,
      description:
        "Libra's desire for harmony and Scorpio's intensity can create both challenges and a transformative bond.",
    },
    sagittarius: {
      score: 75,
      description:
        "Libra and Sagittarius share optimism and a love for social interaction, creating a harmonious match.",
    },
    capricorn: {
      score: 55,
      description: "Libra's social nature and Capricorn's reserved approach can create significant differences.",
    },
    aquarius: {
      score: 85,
      description: "Libra and Aquarius share intellectual interests and social values, creating an ideal partnership.",
    },
    pisces: {
      score: 70,
      description:
        "Libra's rationality and Pisces' emotionality can create both challenges and a balanced relationship.",
    },
  },
  scorpio: {
    aries: {
      score: 80,
      description:
        "Scorpio and Aries share intensity and passion, creating a powerful but potentially volatile connection.",
    },
    taurus: {
      score: 90,
      description: "Scorpio and Taurus are opposite signs with a powerful attraction and deep loyalty to each other.",
    },
    gemini: {
      score: 45,
      description: "Scorpio's intensity and Gemini's light approach can create challenges in understanding each other.",
    },
    cancer: {
      score: 95,
      description: "Scorpio and Cancer share emotional depth and intuition, creating a powerful emotional connection.",
    },
    leo: {
      score: 70,
      description:
        "Scorpio and Leo both have strong wills and passion, creating an intense but potentially challenging match.",
    },
    virgo: {
      score: 85,
      description:
        "Scorpio and Virgo share analytical minds and depth, creating a potentially transformative relationship.",
    },
    libra: {
      score: 60,
      description:
        "Scorpio's intensity and Libra's desire for harmony can create both challenges and a transformative bond.",
    },
    scorpio: {
      score: 90,
      description:
        "Two Scorpios create a deeply intense, passionate, and transformative relationship with powerful connection.",
    },
    sagittarius: {
      score: 50,
      description: "Scorpio's desire for emotional depth and Sagittarius' need for freedom can create challenges.",
    },
    capricorn: {
      score: 85,
      description:
        "Scorpio and Capricorn share determination and depth, creating a powerful and ambitious partnership.",
    },
    aquarius: {
      score: 40,
      description: "Scorpio's emotional intensity and Aquarius' detachment can create significant differences.",
    },
    pisces: {
      score: 95,
      description:
        "Scorpio and Pisces share emotional depth, intuition, and spiritual connection, creating an ideal match.",
    },
  },
  sagittarius: {
    aries: {
      score: 95,
      description:
        "Sagittarius and Aries share a love for adventure and independence, making for an exciting partnership.",
    },
    taurus: {
      score: 40,
      description: "Sagittarius' need for freedom and Taurus' desire for stability can create fundamental challenges.",
    },
    gemini: {
      score: 85,
      description: "Sagittarius and Gemini share a love for freedom, adventure, and philosophical discussions.",
    },
    cancer: {
      score: 40,
      description: "Sagittarius' desire for freedom and Cancer's need for security can create fundamental challenges.",
    },
    leo: {
      score: 85,
      description: "Sagittarius and Leo share optimism and enthusiasm for life, creating an adventurous partnership.",
    },
    virgo: {
      score: 40,
      description: "Sagittarius' free spirit and Virgo's need for order can create fundamental challenges.",
    },
    libra: {
      score: 75,
      description:
        "Sagittarius and Libra share optimism and a love for social interaction, creating a harmonious match.",
    },
    scorpio: {
      score: 50,
      description: "Sagittarius' need for freedom and Scorpio's desire for emotional depth can create challenges.",
    },
    sagittarius: {
      score: 80,
      description: "Two Sagittarians create a relationship full of adventure, freedom, and philosophical exploration.",
    },
    capricorn: {
      score: 45,
      description: "Sagittarius' free spirit and Capricorn's traditional approach can create significant differences.",
    },
    aquarius: {
      score: 90,
      description: "Sagittarius and Aquarius share a love for freedom, innovation, and intellectual exploration.",
    },
    pisces: {
      score: 65,
      description: "Sagittarius' straightforwardness and Pisces' sensitivity can create both challenges and balance.",
    },
  },
  capricorn: {
    aries: {
      score: 50,
      description:
        "Capricorn's practicality and Aries' spontaneity can clash, but they can build a strong foundation together.",
    },
    taurus: {
      score: 95,
      description:
        "Capricorn and Taurus share practical values and work ethic, creating a stable and supportive partnership.",
    },
    gemini: {
      score: 40,
      description: "Capricorn's serious nature and Gemini's playful approach can create significant differences.",
    },
    cancer: {
      score: 85,
      description:
        "Capricorn and Cancer are opposite signs that can create a balanced relationship of ambition and nurturing.",
    },
    leo: {
      score: 50,
      description: "Capricorn's reserved nature and Leo's expressive approach can create significant differences.",
    },
    virgo: {
      score: 95,
      description: "Capricorn and Virgo share practical values, work ethic, and ambition, creating an ideal match.",
    },
    libra: {
      score: 55,
      description: "Capricorn's reserved nature and Libra's social approach can create significant differences.",
    },
    scorpio: {
      score: 85,
      description:
        "Capricorn and Scorpio share determination and depth, creating a powerful and ambitious partnership.",
    },
    sagittarius: {
      score: 45,
      description: "Capricorn's traditional approach and Sagittarius' free spirit can create significant differences.",
    },
    capricorn: {
      score: 80,
      description: "Two Capricorns create a relationship based on mutual ambition, practicality, and determination.",
    },
    aquarius: {
      score: 60,
      description:
        "Capricorn's traditional values and Aquarius' progressive ideas can create both challenges and balance.",
    },
    pisces: {
      score: 70,
      description:
        "Capricorn's practicality and Pisces' imagination can create both challenges and a complementary relationship.",
    },
  },
  aquarius: {
    aries: {
      score: 65,
      description:
        "Aquarius and Aries both value independence and can form an intellectually stimulating relationship.",
    },
    taurus: {
      score: 35,
      description:
        "Aquarius' unconventional approach and Taurus' traditional values can create significant differences.",
    },
    gemini: {
      score: 95,
      description: "Aquarius and Gemini share intellectual curiosity and value independence, creating an ideal match.",
    },
    cancer: {
      score: 45,
      description:
        "Aquarius' intellectual detachment and Cancer's emotional approach can create significant differences.",
    },
    leo: {
      score: 65,
      description:
        "Aquarius and Leo are opposite signs that can create a balanced relationship of innovation and warmth.",
    },
    virgo: {
      score: 50,
      description:
        "Aquarius' unconventional nature and Virgo's traditional approach can create significant differences.",
    },
    libra: {
      score: 85,
      description: "Aquarius and Libra share intellectual interests and social values, creating an ideal partnership.",
    },
    scorpio: {
      score: 40,
      description: "Aquarius' detachment and Scorpio's emotional intensity can create significant differences.",
    },
    sagittarius: {
      score: 90,
      description: "Aquarius and Sagittarius share a love for freedom, innovation, and intellectual exploration.",
    },
    capricorn: {
      score: 60,
      description:
        "Aquarius' progressive ideas and Capricorn's traditional values can create both challenges and balance.",
    },
    aquarius: {
      score: 85,
      description:
        "Two Aquarians create a relationship based on intellectual connection, innovation, and independence.",
    },
    pisces: {
      score: 70,
      description:
        "Aquarius' rationality and Pisces' emotionality can create both challenges and a balanced partnership.",
    },
  },
  pisces: {
    aries: {
      score: 60,
      description:
        "Pisces' sensitivity and Aries' directness can create challenges, but also a deeply emotional connection.",
    },
    taurus: {
      score: 80,
      description: "Pisces brings imagination to practical Taurus, while Taurus provides stability for dreamy Pisces.",
    },
    gemini: {
      score: 55,
      description:
        "Pisces' emotionality and Gemini's rationality can create challenges, but also a balanced partnership.",
    },
    cancer: {
      score: 90,
      description: "Pisces and Cancer share emotional depth and intuition, creating a deeply sympathetic connection.",
    },
    leo: {
      score: 60,
      description:
        "Pisces' sensitivity and Leo's confidence can create both challenges and a complementary relationship.",
    },
    virgo: {
      score: 75,
      description:
        "Pisces and Virgo are opposite signs that can create a balanced relationship of imagination and practicality.",
    },
    libra: {
      score: 70,
      description:
        "Pisces' emotionality and Libra's rationality can create both challenges and a balanced relationship.",
    },
    scorpio: {
      score: 95,
      description:
        "Pisces and Scorpio share emotional depth, intuition, and spiritual connection, creating an ideal match.",
    },
    sagittarius: {
      score: 65,
      description: "Pisces' sensitivity and Sagittarius' straightforwardness can create both challenges and balance.",
    },
    capricorn: {
      score: 70,
      description:
        "Pisces' imagination and Capricorn's practicality can create both challenges and a complementary relationship.",
    },
    aquarius: {
      score: 70,
      description:
        "Pisces' emotionality and Aquarius' rationality can create both challenges and a balanced partnership.",
    },
    pisces: {
      score: 90,
      description:
        "Two Pisces create a deeply intuitive, emotional, and spiritual connection with mutual understanding.",
    },
  },
}

export default function ZodiacMatchPage() {
  const [yourSign, setYourSign] = useState("")
  const [partnerSign, setPartnerSign] = useState("")
  const [result, setResult] = useState<null | {
    score: number
    description: string
    elements: string
    planets: string
  }>(null)
  const [isCalculating, setIsCalculating] = useState(false)
  const { toast } = useToast()

  const zodiacElements = {
    aries: "Fire",
    taurus: "Earth",
    gemini: "Air",
    cancer: "Water",
    leo: "Fire",
    virgo: "Earth",
    libra: "Air",
    scorpio: "Water",
    sagittarius: "Fire",
    capricorn: "Earth",
    aquarius: "Air",
    pisces: "Water",
  }

  const zodiacPlanets = {
    aries: "Mars",
    taurus: "Venus",
    gemini: "Mercury",
    cancer: "Moon",
    leo: "Sun",
    virgo: "Mercury",
    libra: "Venus",
    scorpio: "Pluto & Mars",
    sagittarius: "Jupiter",
    capricorn: "Saturn",
    aquarius: "Uranus & Saturn",
    pisces: "Neptune & Jupiter",
  }

  const calculateCompatibility = () => {
    if (!yourSign || !partnerSign) {
      toast({
        title: "Signs required",
        description: "Please select both zodiac signs to calculate compatibility",
        variant: "destructive",
      })
      return
    }

    setIsCalculating(true)
    setTimeout(() => {
      const compatibility = compatibilityData[yourSign][partnerSign]

      // Generate element compatibility description
      const yourElement = zodiacElements[yourSign as keyof typeof zodiacElements]
      const partnerElement = zodiacElements[partnerSign as keyof typeof zodiacElements]
      let elementDescription = `Your element (${yourElement}) and their element (${partnerElement}) `

      if (yourElement === partnerElement) {
        elementDescription += "are the same, creating natural harmony and understanding."
      } else if (
        (yourElement === "Fire" && partnerElement === "Air") ||
        (yourElement === "Air" && partnerElement === "Fire") ||
        (yourElement === "Earth" && partnerElement === "Water") ||
        (yourElement === "Water" && partnerElement === "Earth")
      ) {
        elementDescription += "complement each other well, creating a balanced relationship."
      } else {
        elementDescription += "may create some challenges, but can also lead to growth and learning."
      }

      // Generate planet compatibility
      const yourPlanet = zodiacPlanets[yourSign as keyof typeof zodiacPlanets]
      const partnerPlanet = zodiacPlanets[partnerSign as keyof typeof zodiacPlanets]

      setResult({
        score: compatibility.score,
        description: compatibility.description,
        elements: elementDescription,
        planets: `Your ruling planet(s) (${yourPlanet}) and their ruling planet(s) (${partnerPlanet}) influence how you communicate and connect.`,
      })

      setIsCalculating(false)
    }, 1500)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-purple-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-purple-600 mb-6 text-center">Zodiac Love Match</h1>

        <Card className="max-w-md mx-auto border-purple-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-purple-600 flex items-center justify-center gap-2">
              <Star className="h-5 w-5 text-yellow-500" />
              Zodiac Compatibility
            </CardTitle>
            <CardDescription>Discover your astrological love compatibility</CardDescription>
          </CardHeader>

          <CardContent>
            {!result ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="yourSign">Your Zodiac Sign</Label>
                  <Select value={yourSign} onValueChange={setYourSign}>
                    <SelectTrigger id="yourSign" className="border-purple-200 focus:border-purple-400">
                      <SelectValue placeholder="Select your sign" />
                    </SelectTrigger>
                    <SelectContent>
                      {zodiacSigns.map((sign) => (
                        <SelectItem key={sign.value} value={sign.value}>
                          {sign.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-center my-2">
                  <div className="w-full h-px bg-purple-100"></div>
                  <Star className="mx-2 h-4 w-4 text-yellow-500 flex-shrink-0" />
                  <div className="w-full h-px bg-purple-100"></div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="partnerSign">Partner's Zodiac Sign</Label>
                  <Select value={partnerSign} onValueChange={setPartnerSign}>
                    <SelectTrigger id="partnerSign" className="border-purple-200 focus:border-purple-400">
                      <SelectValue placeholder="Select their sign" />
                    </SelectTrigger>
                    <SelectContent>
                      {zodiacSigns.map((sign) => (
                        <SelectItem key={sign.value} value={sign.value}>
                          {sign.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            ) : (
              <div className="py-4 text-center space-y-4">
                <div className="relative mx-auto w-40 h-40 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-purple-100 animate-pulse"></div>
                  <div className="relative z-10">
                    <div className="text-4xl font-bold text-purple-600">{result.score}%</div>
                    <div className="text-sm text-purple-500 mt-1">Compatibility</div>
                  </div>
                </div>
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-purple-600 flex items-center justify-center gap-2">
                    <Sparkles className="h-4 w-4 text-yellow-500" />
                    Cosmic Connection
                    <Sparkles className="h-4 w-4 text-yellow-500" />
                  </h3>
                  <div className="bg-purple-50 p-4 rounded-lg border border-purple-200 text-left">
                    <p className="text-purple-800 mb-3">{result.description}</p>
                    <div className="space-y-2 mt-4">
                      <p className="text-sm text-purple-700">
                        <span className="font-bold">Elements:</span> {result.elements}
                      </p>
                      <p className="text-sm text-purple-700">
                        <span className="font-bold">Planetary Influence:</span> {result.planets}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>

          <CardFooter>
            <Button
              onClick={result ? () => setResult(null) : calculateCompatibility}
              className={`w-full ${
                !result
                  ? "bg-purple-500 hover:bg-purple-600 text-white"
                  : "bg-purple-100 hover:bg-purple-200 text-purple-600"
              }`}
              disabled={isCalculating}
            >
              {isCalculating ? (
                <>
                  Consulting the stars<span className="animate-pulse">...</span>
                </>
              ) : result ? (
                <>Try Another Match</>
              ) : (
                <>Calculate Compatibility</>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}

