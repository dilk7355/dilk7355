"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Gift, Heart, Copy } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

export default function LoveProposalGeneratorPage() {
  const [yourName, setYourName] = useState("")
  const [crushName, setCrushName] = useState("")
  const [style, setStyle] = useState("romantic")
  const [proposal, setProposal] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const { toast } = useToast()

  const proposalTemplates = {
    romantic: [
      "{crushName}, from the moment I first saw you, my heart knew what my mind would soon discover - that you are the one I want to share my life with. Every moment with you feels like a gift, and I can't imagine my future without you in it. Will you make me the happiest person alive and be mine? With all my love, {yourName}",

      "My dearest {crushName}, in a world full of ordinary moments, every second with you feels extraordinary. Your smile lights up my darkest days, and your laugh is the sweetest melody to my ears. I've fallen deeply in love with you, and I can't hold it in any longer. Would you do me the honor of being my partner? Forever yours, {yourName}",

      "{crushName}, they say when you know, you know - and I've known since the day we met that there was something special between us. You've captured my heart in ways I never thought possible. I cherish every moment we spend together and dream of countless more. Will you be mine? With all my heart, {yourName}",
    ],

    funny: [
      "Hey {crushName}, I've conducted extensive research and calculated that we have a 99.9% compatibility rate (the 0.1% is because you might snore, but I'm willing to invest in earplugs). So, what do you say - want to make this official and be my partner in crime? Warning: Side effects may include excessive happiness and spontaneous dancing. Hopefully not regretting this, {yourName}",

      "Attention {crushName}! This is an official notification that you've been selected for the prestigious position of being my significant other. Benefits include unlimited hugs, terrible jokes on demand, and someone who will always eat the food you don't want. No previous experience required! Applications close soon, so please respond ASAP. Your potential future better half, {yourName}",

      "Dear {crushName}, I've fallen for you harder than I fall when I trip over my own feet (which, as you know, is pretty hard). You make my heart do that weird flippy thing, and my face hurts from smiling whenever I think about you. So what do you say - ready to embark on this crazy adventure called dating me? I promise it won't be boring! Fingers crossed, {yourName}",
    ],

    poetic: [
      "My beloved {crushName}, like stars that guide sailors home, your eyes have led my heart to its rightful shore. In the garden of life, you are the rarest bloom, captivating me with your beauty and grace. Each day without you feels like winter; each moment with you, eternal spring. Would you grant me the greatest joy and allow me to call you mine? With undying devotion, {yourName}",

      "{crushName}, in the quiet spaces between heartbeats, I hear your name. You are the verse I've been trying to write, the melody that lingers in my mind. Time stands still when our eyes meet, and in that stillness, I've found my truth - that my soul has recognized yours. Will you walk this poetic journey of life with me? Yours in every rhyme and reason, {yourName}",

      "To my cherished {crushName}, you are the poem I never knew I needed to read, the song I never knew I longed to hear. Your laughter is the rhythm to which my heart beats, your smile the light that guides me through darkness. In this vast universe of chance and change, finding you feels like destiny. Would you make my heart complete and be mine? Forever enchanted, {yourName}",
    ],

    simple: [
      "{crushName}, I like you. A lot. I've liked you for a while now, and I think we could be great together. Would you like to be my partner? - {yourName}",

      "Hey {crushName}, I've been wanting to tell you something important. I have feelings for you, and I'd really like us to be more than friends. What do you think? - {yourName}",

      "Dear {crushName}, I'm not good with fancy words, but I want you to know that you mean a lot to me. I'd like us to be together. Would you give us a chance? - {yourName}",
    ],
  }

  const generateProposal = () => {
    if (!yourName || !crushName) {
      toast({
        title: "Names required",
        description: "Please enter both names to generate a proposal",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    setTimeout(() => {
      // Select a random proposal from the chosen style
      const templates = proposalTemplates[style as keyof typeof proposalTemplates]
      const randomTemplate = templates[Math.floor(Math.random() * templates.length)]

      // Fill in the template with the provided names
      const generatedProposal = randomTemplate.replace(/{yourName}/g, yourName).replace(/{crushName}/g, crushName)

      setProposal(generatedProposal)
      setIsGenerating(false)
    }, 1500)
  }

  const copyToClipboard = () => {
    if (proposal) {
      navigator.clipboard.writeText(proposal)
      toast({
        title: "Copied to clipboard!",
        description: "Your love proposal has been copied to your clipboard.",
      })
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-pink-200 to-red-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-pink-600 mb-6 text-center">Love Proposal Generator</h1>

        <Card className="max-w-2xl mx-auto border-pink-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-pink-600 flex items-center justify-center gap-2">
              <Gift className="h-5 w-5 text-pink-500" />
              Create the Perfect Proposal
            </CardTitle>
            <CardDescription>Generate a heartfelt message to express your feelings</CardDescription>
          </CardHeader>

          <CardContent>
            <div className="space-y-4">
              {!proposal ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="yourName">Your Name</Label>
                      <Input
                        id="yourName"
                        placeholder="Enter your name"
                        value={yourName}
                        onChange={(e) => setYourName(e.target.value)}
                        className="border-pink-200 focus:border-pink-400"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="crushName">Your Crush's Name</Label>
                      <Input
                        id="crushName"
                        placeholder="Enter their name"
                        value={crushName}
                        onChange={(e) => setCrushName(e.target.value)}
                        className="border-pink-200 focus:border-pink-400"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="style">Proposal Style</Label>
                    <Select value={style} onValueChange={setStyle}>
                      <SelectTrigger id="style" className="border-pink-200 focus:border-pink-400">
                        <SelectValue placeholder="Choose a style" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="romantic">Romantic</SelectItem>
                        <SelectItem value="funny">Funny</SelectItem>
                        <SelectItem value="poetic">Poetic</SelectItem>
                        <SelectItem value="simple">Simple & Direct</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div className="relative">
                    <div className="absolute -top-2 -left-2">
                      <Heart className="h-8 w-8 text-pink-500 fill-pink-500" />
                    </div>
                    <div className="bg-pink-50 p-6 pt-8 rounded-lg border border-pink-200">
                      <p className="text-gray-800 whitespace-pre-line">{proposal}</p>
                    </div>
                    <div className="absolute -bottom-2 -right-2">
                      <Heart className="h-8 w-8 text-pink-500 fill-pink-500" />
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <Button variant="outline" size="sm" onClick={copyToClipboard} className="flex items-center gap-1">
                      <Copy className="h-4 w-4" />
                      Copy
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </CardContent>

          <CardFooter>
            <Button
              onClick={proposal ? () => setProposal(null) : generateProposal}
              className={`w-full ${
                !proposal ? "bg-pink-500 hover:bg-pink-600 text-white" : "bg-pink-100 hover:bg-pink-200 text-pink-600"
              }`}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  Creating your proposal<span className="animate-pulse">...</span>
                </>
              ) : proposal ? (
                <>Create Another Proposal</>
              ) : (
                <>Generate Love Proposal</>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}

