"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Upload, Download, ImageIcon, Edit, Check, X, Smartphone } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

type EditableArea = {
  id: number
  x: number
  y: number
  width: number
  height: number
  text: string
  isEditing: boolean
}

export default function WhatsAppMessageEditorPage() {
  const [image, setImage] = useState<string | null>(null)
  const [editableAreas, setEditableAreas] = useState<EditableArea[]>([])
  const [isAddingArea, setIsAddingArea] = useState(false)
  const [newArea, setNewArea] = useState<{ startX: number; startY: number; endX: number; endY: number } | null>(null)
  const [editedImage, setEditedImage] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  const imageRef = useRef<HTMLImageElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const imageContainerRef = useRef<HTMLDivElement>(null)

  const { toast } = useToast()

  // Check if device is mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)

    return () => {
      window.removeEventListener("resize", checkMobile)
    }
  }, [])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Check if file is an image
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file type",
        description: "Please upload an image file (JPEG, PNG, etc.)",
        variant: "destructive",
      })
      return
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload an image smaller than 5MB",
        variant: "destructive",
      })
      return
    }

    const reader = new FileReader()
    reader.onload = () => {
      setImage(reader.result as string)
      setEditableAreas([])
      setEditedImage(null)
    }
    reader.readAsDataURL(file)
  }

  // Handle double click to create a text area
  const handleDoubleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!imageContainerRef.current || !image) return

    const rect = imageContainerRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    // Create a default sized text area where the user double-clicked
    const defaultWidth = isMobile ? 150 : 200
    const defaultHeight = isMobile ? 40 : 50

    // Make sure the area stays within the image bounds
    const maxWidth = imageContainerRef.current.clientWidth
    const maxHeight = imageContainerRef.current.clientHeight

    const width = Math.min(defaultWidth, maxWidth - x)
    const height = Math.min(defaultHeight, maxHeight - y)

    setEditableAreas([
      ...editableAreas,
      {
        id: Date.now(),
        x,
        y,
        width,
        height,
        text: "Double-tap to edit",
        isEditing: true,
      },
    ])
  }

  const handleImageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!imageContainerRef.current || !image) return

    const rect = imageContainerRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    if (isAddingArea) {
      if (!newArea) {
        // Start drawing a new area
        setNewArea({
          startX: x,
          startY: y,
          endX: x,
          endY: y,
        })
      } else {
        // Finish drawing the area
        const width = Math.abs(newArea.endX - newArea.startX)
        const height = Math.abs(newArea.endY - newArea.startY)

        if (width > 10 && height > 10) {
          const startX = Math.min(newArea.startX, newArea.endX)
          const startY = Math.min(newArea.startY, newArea.endY)

          setEditableAreas([
            ...editableAreas,
            {
              id: Date.now(),
              x: startX,
              y: startY,
              width,
              height,
              text: "Tap to edit",
              isEditing: false,
            },
          ])
        }

        setNewArea(null)
        setIsAddingArea(false)
      }
    } else {
      // Check if clicked on an existing area
      const clickedArea = editableAreas.find(
        (area) => x >= area.x && x <= area.x + area.width && y >= area.y && y <= area.y + area.height,
      )

      if (clickedArea) {
        setEditableAreas(
          editableAreas.map((area) =>
            area.id === clickedArea.id ? { ...area, isEditing: true } : { ...area, isEditing: false },
          ),
        )
      } else {
        // If clicked outside any area, close all editing
        setEditableAreas(editableAreas.map((area) => ({ ...area, isEditing: false })))
      }
    }
  }

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!imageContainerRef.current || !image) return

    const touch = e.touches[0]
    const rect = imageContainerRef.current.getBoundingClientRect()
    const x = touch.clientX - rect.left
    const y = touch.clientY - rect.top

    // Check if touched on an existing area
    const touchedArea = editableAreas.find(
      (area) => x >= area.x && x <= area.x + area.width && y >= area.y && y <= area.y + area.height,
    )

    if (touchedArea) {
      setEditableAreas(
        editableAreas.map((area) =>
          area.id === touchedArea.id ? { ...area, isEditing: true } : { ...area, isEditing: false },
        ),
      )
    }
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isAddingArea || !newArea || !imageContainerRef.current) return

    const rect = imageContainerRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    setNewArea({
      ...newArea,
      endX: x,
      endY: y,
    })
  }

  const updateAreaText = (id: number, text: string) => {
    setEditableAreas(editableAreas.map((area) => (area.id === id ? { ...area, text } : area)))
  }

  const finishEditing = (id: number) => {
    setEditableAreas(editableAreas.map((area) => (area.id === id ? { ...area, isEditing: false } : area)))
  }

  const deleteArea = (id: number) => {
    setEditableAreas(editableAreas.filter((area) => area.id !== id))
  }

  // Resize an area by dragging its corners
  const resizeArea = (id: number, newWidth: number, newHeight: number) => {
    setEditableAreas(
      editableAreas.map((area) => (area.id === id ? { ...area, width: newWidth, height: newHeight } : area)),
    )
  }

  const generateEditedImage = () => {
    if (!image || !canvasRef.current || !imageRef.current) return

    setIsGenerating(true)

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")

    if (!ctx) {
      toast({
        title: "Error",
        description: "Could not generate image. Canvas context not available.",
        variant: "destructive",
      })
      setIsGenerating(false)
      return
    }

    // Set canvas dimensions to match the image
    canvas.width = imageRef.current.naturalWidth
    canvas.height = imageRef.current.naturalHeight

    // Draw the original image
    ctx.drawImage(imageRef.current, 0, 0)

    // Calculate scale factor between displayed image and original image
    const scaleX = imageRef.current.naturalWidth / imageRef.current.clientWidth
    const scaleY = imageRef.current.naturalHeight / imageRef.current.clientHeight

    // Draw text for each editable area
    editableAreas.forEach((area) => {
      // Scale coordinates to match original image size
      const scaledX = area.x * scaleX
      const scaledY = area.y * scaleY
      const scaledWidth = area.width * scaleX
      const scaledHeight = area.height * scaleY

      // Clear the area first (optional, for better text visibility)
      ctx.fillStyle = "white"
      ctx.fillRect(scaledX, scaledY, scaledWidth, scaledHeight)

      // Draw the text
      ctx.fillStyle = "black"
      ctx.font = `${Math.max(12, scaledHeight * 0.7)}px Arial`
      ctx.textBaseline = "top"

      // Handle text wrapping
      const words = area.text.split(" ")
      let line = ""
      let lineY = scaledY + 5
      const lineHeight = Math.max(14, scaledHeight * 0.8)

      for (let i = 0; i < words.length; i++) {
        const testLine = line + words[i] + " "
        const metrics = ctx.measureText(testLine)

        if (metrics.width > scaledWidth - 10 && i > 0) {
          ctx.fillText(line, scaledX + 5, lineY)
          line = words[i] + " "
          lineY += lineHeight

          // Check if we've exceeded the height
          if (lineY + lineHeight > scaledY + scaledHeight) {
            break
          }
        } else {
          line = testLine
        }
      }

      ctx.fillText(line, scaledX + 5, lineY)
    })

    // Convert canvas to data URL
    const dataUrl = canvas.toDataURL("image/jpeg", 0.9)
    setEditedImage(dataUrl)
    setIsGenerating(false)

    toast({
      title: "Success",
      description: "Image generated successfully! You can now download it.",
    })
  }

  const downloadImage = () => {
    if (!editedImage) return

    const link = document.createElement("a")
    link.href = editedImage
    link.download = "edited-whatsapp-message.jpg"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-green-200 to-blue-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-green-600 mb-6 text-center">WhatsApp Message Editor</h1>

        <Card className="max-w-4xl mx-auto border-green-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-green-600 flex items-center justify-center gap-2">
              <Edit className="h-5 w-5 text-green-500" />
              WhatsApp Message Editor
            </CardTitle>
            <CardDescription>Upload a screenshot, edit the text, and download the modified image</CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            <div className="flex justify-center">
              <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="bg-green-500 hover:bg-green-600 text-white"
              >
                <Upload className="mr-2 h-4 w-4" /> Upload Screenshot
              </Button>
            </div>

            {image && (
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2 justify-center">
                  <Button
                    variant={isAddingArea ? "destructive" : "outline"}
                    onClick={() => setIsAddingArea(!isAddingArea)}
                    className="text-sm"
                  >
                    {isAddingArea ? "Cancel Selection" : "Select Text Area"}
                  </Button>

                  <Button
                    variant="outline"
                    onClick={generateEditedImage}
                    disabled={editableAreas.length === 0 || isGenerating}
                    className="text-sm"
                  >
                    <ImageIcon className="mr-2 h-4 w-4" />
                    {isGenerating ? "Generating..." : "Generate Edited Image"}
                  </Button>

                  {editedImage && (
                    <Button onClick={downloadImage} className="bg-blue-500 hover:bg-blue-600 text-white text-sm">
                      <Download className="mr-2 h-4 w-4" /> Download Image
                    </Button>
                  )}
                </div>

                <div className="bg-yellow-100 p-3 rounded-lg text-sm text-yellow-800 flex items-center gap-2">
                  <Smartphone className="h-4 w-4 flex-shrink-0" />
                  <p>
                    <strong>Tip:</strong> Double-tap anywhere on the image to create a text area, or tap on existing
                    areas to edit them.
                  </p>
                </div>

                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <div className="border rounded-lg overflow-hidden bg-gray-100 relative">
                      <div
                        ref={imageContainerRef}
                        className="relative cursor-crosshair"
                        onClick={handleImageClick}
                        onDoubleClick={handleDoubleClick}
                        onTouchStart={handleTouchStart}
                        onMouseMove={handleMouseMove}
                      >
                        <img
                          ref={imageRef}
                          src={image || "/placeholder.svg"}
                          alt="Uploaded screenshot"
                          className="max-w-full h-auto"
                        />

                        {/* Editable areas */}
                        {editableAreas.map((area) => (
                          <div
                            key={area.id}
                            className={`absolute border-2 ${area.isEditing ? "border-blue-500" : "border-green-500"} bg-white/30`}
                            style={{
                              left: `${area.x}px`,
                              top: `${area.y}px`,
                              width: `${area.width}px`,
                              height: `${area.height}px`,
                            }}
                          >
                            {area.isEditing ? (
                              <div className="absolute top-0 right-0 flex">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    finishEditing(area.id)
                                  }}
                                  className="bg-green-500 text-white p-1 rounded-sm"
                                >
                                  <Check className="h-3 w-3" />
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    deleteArea(area.id)
                                  }}
                                  className="bg-red-500 text-white p-1 rounded-sm"
                                >
                                  <X className="h-3 w-3" />
                                </button>
                              </div>
                            ) : (
                              <div className="absolute inset-0 flex items-center justify-center text-xs text-green-800 font-medium overflow-hidden p-1">
                                {area.text.length > 20 ? area.text.substring(0, 20) + "..." : area.text}
                              </div>
                            )}

                            {/* Resize handle */}
                            {area.isEditing && (
                              <div
                                className="absolute bottom-0 right-0 w-4 h-4 bg-blue-500 cursor-se-resize"
                                onMouseDown={(e) => {
                                  e.stopPropagation()

                                  const startX = e.clientX
                                  const startY = e.clientY
                                  const startWidth = area.width
                                  const startHeight = area.height

                                  const handleMouseMove = (moveEvent: MouseEvent) => {
                                    const deltaX = moveEvent.clientX - startX
                                    const deltaY = moveEvent.clientY - startY

                                    const newWidth = Math.max(50, startWidth + deltaX)
                                    const newHeight = Math.max(20, startHeight + deltaY)

                                    resizeArea(area.id, newWidth, newHeight)
                                  }

                                  const handleMouseUp = () => {
                                    document.removeEventListener("mousemove", handleMouseMove)
                                    document.removeEventListener("mouseup", handleMouseUp)
                                  }

                                  document.addEventListener("mousemove", handleMouseMove)
                                  document.addEventListener("mouseup", handleMouseUp)
                                }}
                              />
                            )}
                          </div>
                        ))}

                        {/* Drawing new area */}
                        {isAddingArea && newArea && (
                          <div
                            className="absolute border-2 border-dashed border-blue-500 bg-blue-100/30"
                            style={{
                              left: `${Math.min(newArea.startX, newArea.endX)}px`,
                              top: `${Math.min(newArea.startY, newArea.endY)}px`,
                              width: `${Math.abs(newArea.endX - newArea.startX)}px`,
                              height: `${Math.abs(newArea.endY - newArea.startY)}px`,
                            }}
                          ></div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex-1">
                    <div className="space-y-4">
                      <h3 className="font-medium text-green-700">Edit Selected Text</h3>

                      {editableAreas
                        .filter((area) => area.isEditing)
                        .map((area) => (
                          <div key={area.id} className="space-y-2">
                            <Textarea
                              value={area.text}
                              onChange={(e) => updateAreaText(area.id, e.target.value)}
                              placeholder="Enter text here..."
                              className="min-h-[100px] border-green-200 focus:border-green-400"
                            />
                            <div className="flex justify-end gap-2">
                              <Button size="sm" variant="outline" onClick={() => finishEditing(area.id)}>
                                <Check className="mr-1 h-3 w-3" /> Done
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => deleteArea(area.id)}>
                                <X className="mr-1 h-3 w-3" /> Delete
                              </Button>
                            </div>
                          </div>
                        ))}

                      {editableAreas.length > 0 && !editableAreas.some((area) => area.isEditing) && (
                        <div className="text-sm text-gray-500 italic">Tap on a highlighted area to edit its text</div>
                      )}

                      {editableAreas.length === 0 && (
                        <div className="text-sm text-gray-500 italic">
                          {isAddingArea
                            ? "Tap and drag to select a text area on the image"
                            : "Double-tap anywhere on the image to add text, or use 'Select Text Area' button"}
                        </div>
                      )}
                    </div>

                    {editedImage && (
                      <div className="mt-6">
                        <h3 className="font-medium text-green-700 mb-2">Generated Image</h3>
                        <div className="border rounded-lg overflow-hidden bg-gray-100">
                          <img
                            src={editedImage || "/placeholder.svg"}
                            alt="Edited screenshot"
                            className="max-w-full h-auto"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Hidden canvas for image generation */}
            <canvas ref={canvasRef} className="hidden"></canvas>
          </CardContent>

          <CardFooter className="flex justify-center">
            <div className="text-sm text-gray-500 max-w-md text-center">
              <p>
                <strong>How to use:</strong> Upload a WhatsApp or Instagram screenshot, double-tap to create text areas,
                edit the text, generate the edited image, and download it.
              </p>
            </div>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}

