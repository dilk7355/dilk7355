import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import FloatingHearts from "@/components/floating-hearts"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-pink-200 to-pink-300 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <Card className="max-w-3xl mx-auto border-pink-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-pink-600">
              Privacy Policy for TrueLoveCalculator.fun
            </CardTitle>
          </CardHeader>
          <CardContent className="prose prose-pink max-w-none">
            <p>
              At TrueLoveCalculator.fun, we value your privacy. This privacy policy document outlines the types of
              personal information that is received and collected by TrueLoveCalculator.fun and how it is used.
            </p>

            <h3>1. Information We Collect:</h3>
            <p>
              We collect minimal personal information when you visit or use our website. This may include your IP
              address, browser type, and other usage data. If you subscribe to our services or sign up for newsletters,
              we may collect personal details like your name and email address.
            </p>

            <h3>2. How We Use Your Information:</h3>
            <p>
              The information we collect is used to improve the website's user experience, maintain the website, and
              provide content and advertisements that may be of interest to you. We do not share your personal data with
              third parties unless required by law.
            </p>

            <h3>3. Cookies:</h3>
            <p>
              Our website uses cookies to track your preferences and activity. You can manage cookies through your
              browser settings.
            </p>

            <h3>4. Data Protection:</h3>
            <p>We take reasonable measures to protect your data but cannot guarantee absolute security.</p>

            <h3>5. Changes to Privacy Policy:</h3>
            <p>
              We reserve the right to update this policy. Any changes will be posted on this page with an updated date.
              For any questions, you can contact us at contact@truelovecalculator.fun.
            </p>
          </CardContent>
        </Card>
      </main>
      <SiteFooter />
    </div>
  )
}

