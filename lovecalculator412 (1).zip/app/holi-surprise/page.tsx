"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Sparkles, Copy, Share2, ExternalLink } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"
import { useRouter } from "next/navigation"

// Function to generate a random ID
const generateUniqueId = () => {
  return Math.random().toString(36).substring(2, 8)
}

export default function HoliSurprisePage() {
  const [message, setMessage] = useState("")
  const [senderName, setSenderName] = useState("")
  const [uniqueId, setUniqueId] = useState("")
  const [generatedLink, setGeneratedLink] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  // Generate a unique ID when the component mounts
  useEffect(() => {
    setUniqueId(generateUniqueId())
  }, [])

  const createHoliSurprise = () => {
    if (!message.trim()) {
      toast({
        title: "Message required",
        description: "Please enter a Holi greeting message",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    // Create the greeting data
    const greetingData = {
      message: message.trim(),
      sender: senderName.trim() || "Someone special",
      createdAt: new Date().toISOString(),
    }

    // In a real app, this would be saved to a database
    // For this demo, we'll use localStorage
    try {
      // Store the greeting data in localStorage
      localStorage.setItem(`holi-surprise-${uniqueId}`, JSON.stringify(greetingData))

      // Generate the full URL
      const baseUrl = window.location.origin
      const fullUrl = `${baseUrl}/holi-surprise/${uniqueId}`
      setGeneratedLink(fullUrl)

      toast({
        title: "Holi Surprise created!",
        description: "Your colorful greeting is ready to share",
      })
    } catch (error) {
      toast({
        title: "Error creating surprise",
        description: "There was a problem creating your Holi surprise",
        variant: "destructive",
      })
    }

    setIsGenerating(false)
  }

  const copyToClipboard = () => {
    if (!generatedLink) return

    navigator.clipboard.writeText(generatedLink)
    toast({
      title: "Copied to clipboard!",
      description: "Share this link with your friends and family",
    })
  }

  const shareLink = async () => {
    if (!generatedLink) return

    if (navigator.share) {
      try {
        await navigator.share({
          title: "Holi Surprise for you!",
          text: `${senderName || "Someone"} sent you a colorful Holi surprise! Click to see:`,
          url: generatedLink,
        })
      } catch (error) {
        console.error("Error sharing:", error)
      }
    } else {
      copyToClipboard()
    }
  }

  const previewSurprise = () => {
    if (!generatedLink) return

    // Open in a new tab
    window.open(generatedLink, "_blank")
  }

  const createNewSurprise = () => {
    setMessage("")
    setSenderName("")
    setUniqueId(generateUniqueId())
    setGeneratedLink("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-violet-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-violet-600 mb-6 text-center">Holi Surprise Creator</h1>

        <Card className="max-w-md mx-auto border-violet-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-violet-600 flex items-center justify-center gap-2">
              <Sparkles className="h-5 w-5 text-violet-500" />
              Holi Surprise
            </CardTitle>
            <CardDescription>Create a colorful Holi greeting to surprise your friends</CardDescription>
          </CardHeader>

          <CardContent>
            {!generatedLink ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="message">Your Holi Message</Label>
                  <Input
                    id="message"
                    placeholder="Happy Holi! May your life be filled with colors!"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="border-violet-200 focus:border-violet-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="senderName">Your Name (Optional)</Label>
                  <Input
                    id="senderName"
                    placeholder="Your name"
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    className="border-violet-200 focus:border-violet-400"
                  />
                </div>

                <div className="bg-violet-50 p-4 rounded-lg border border-violet-200 mt-4">
                  <p className="text-sm text-violet-700">
                    <Sparkles className="h-4 w-4 inline-block mr-1" />
                    When your friends open the link, they'll see a colorful Holi animation with your message!
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-violet-50 p-4 rounded-lg border border-violet-200">
                  <h3 className="font-medium text-violet-700 mb-2">Your Holi Surprise is ready!</h3>
                  <p className="text-sm text-violet-600 break-all">{generatedLink}</p>
                </div>

                <div className="flex flex-col gap-3">
                  <Button onClick={copyToClipboard} className="flex items-center gap-2">
                    <Copy className="h-4 w-4" />
                    Copy Link
                  </Button>

                  <Button onClick={shareLink} variant="outline" className="flex items-center gap-2 border-violet-200">
                    <Share2 className="h-4 w-4" />
                    Share
                  </Button>

                  <Button onClick={previewSurprise} variant="secondary" className="flex items-center gap-2">
                    <ExternalLink className="h-4 w-4" />
                    Preview
                  </Button>
                </div>

                <div className="bg-pink-50 p-4 rounded-lg border border-pink-200">
                  <p className="text-sm text-pink-700">
                    Share this link with your friends and family to send them a colorful Holi surprise!
                  </p>
                </div>
              </div>
            )}
          </CardContent>

          <CardFooter>
            {!generatedLink ? (
              <Button
                onClick={createHoliSurprise}
                className="w-full bg-violet-500 hover:bg-violet-600 text-white"
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <>
                    Creating your surprise<span className="animate-pulse">...</span>
                  </>
                ) : (
                  <>Create Holi Surprise</>
                )}
              </Button>
            ) : (
              <Button onClick={createNewSurprise} className="w-full bg-violet-100 hover:bg-violet-200 text-violet-600">
                Create Another Surprise
              </Button>
            )}
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}

