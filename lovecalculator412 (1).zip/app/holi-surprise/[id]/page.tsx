"use client"

import { useState, useEffect, useRef } from "react"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Home, Sparkles, Facebook, Send } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import confetti from "canvas-confetti"

// Define the greeting data type
type GreetingData = {
  message: string
  sender: string
  createdAt: string
}

// Colors for Holi
const holiColors = [
  "#FF5252", // Red
  "#FFEB3B", // Yellow
  "#2196F3", // Blue
  "#4CAF50", // Green
  "#9C27B0", // Purple
  "#FF9800", // Orange
  "#00BCD4", // Cyan
  "#F06292", // Pink
]

// Holi shayari collection
const holiShayaris = [
  "रंगों की बरसात में, दिल की बात हो,\nहर पल खुशियों से भरा, ये दिन और रात हो।\nमुबारक हो आपको होली का त्योहार!",
  "गुलाल की थाली सजी है, पिचकारी भी है साथ,\nरंग-बिरंगी होली आई, लेकर खुशियों की बरसात!",
  "लाल पीला हरा गुलाल, उड़ता है यह रंगों का जाल,\nहोली के इस पावन त्योहार पर, आपको मिले खुशियों की बहार!",
  "रंग बरसे भीगे चुनर वाली, रंग बरसे,\nहोली है होली, रंगीली होली,\nमस्ती में डोली, यह होली है होली!",
  "पिचकारी की धार, गुलाल की बौछार,\nअपनों का प्यार, यही है होली का त्योहार!",

  // Adding the new shayaris provided by the user
  "रंगों की बहार आई, संग अपने खुशियां लाई,\nहर गली, हर मोड़ पर, होली की मस्ती छाई।\nगुलाल से सजी हैं गलियां, पिचकारी से भीगा है आसमान,\nखुशियों से खिल उठा हर इंसान।\nचलो मिलकर मनाएं होली, छोड़कर हर शिकवा और गिला,\nइस बार होली में सबको रंग दो दिल से मिला।",

  "लाल, गुलाबी, पीला, नीला,\nहर रंग है कितना खूबसूरत और रंगीला।\nरंग बरसाएगी ये होली, हर मन को भाएगी ये होली,\nहर कोई नाचेगा गाएगा, खुशियों की सौगात लाएगी ये होली।\nमिट जाए हर बैर-द्वेष, रहे सिर्फ प्रेम का एहसास,\nखुशियों से भर जाए हर जीवन, यही होली का है खास अंदाज।",

  "रंगों में बस प्यार बसा हो,\nहर दिल में बस एक अहसास सजा हो।\nमिलकर खेलें सब यह त्यौहार,\nबिना भेदभाव के करें सब प्यार।\nगुझिया की मिठास हो, ठंडाई की मिठास हो,\nसंग अपने अपनों की बात हो, और हर लम्हा खास हो।",

  "पिचकारी से निकली धार, भीग गए सब यार,\nअब ना कोई रहेगा सूखा, हर चेहरे पर रंगों की बौछार।\nमस्ती में झूमे हर इंसान, होली है भाई, छोड़ो हर ग़म और परेशानी,\nरंगों की खुशबू से महक जाए हर गलियां, होली की इस शाम में बस खुशियों की रवानी।",

  "होली में सब भूल जाएं, दुख-दर्द और शिकवे सारे,\nसिर्फ रंगों से रंग जाएं, दोस्त, रिश्ते और नाते सारे।\nकोई भेदभाव ना हो, ना ऊंच-नीच का कोई सवाल,\nबस प्यार ही प्यार हो, हर ओर खुशियों का उबाल।",

  "होली के इस रंगीन मौसम में, हर दिल खिल जाए,\nजो दूर हैं वो भी पास आ जाएं, रिश्ते गहरे बन जाएं।\nदोस्ती की मिठास घुले रंगों में, हर ग़म और दर्द मिट जाए,\nआओ मिलकर खेलें होली, प्यार के रंग में भीग जाएं।",

  "तेरी मोहब्बत के रंग से खेलूं इस बार,\nतेरे गालों पर मल दूं गुलाल बार-बार।\nभीग जाएं हम रंगों में इस तरह,\nकि जुदा करना मुश्किल हो हर बार।",

  "रंग लगाऊं तुझे इस अंदाज में,\nकि हर रंग फीका लगे मेरे प्यार के सामने।\nतेरी हंसी की मिठास घुल जाए रंगों में,\nतेरा नाम लिख दूं गुलाल से हवाओं में।",

  "दोस्ती के रंग से खेलेंगे होली,\nन रखेंगे मन में कोई खटास,\nप्यार से मिलकर बनाएंगे इस त्यौहार को,\nखुशियों का उल्लास।",

  "रंगों से ज्यादा चमकते रहे रिश्ते हमारे,\nहर होली एक नई याद बन जाए हमारे।\nगिले-शिकवे भूलकर गले मिल जाएं,\nहोली की मिठास हमारे दिल में बस जाए।",

  "भांग का नशा, रंगों की बौछार,\nहर कोई नाचे, सब हो बेकरार।\nगुझिया की मिठास, ठंडाई का स्वाद,\nहोली का ये त्यौहार सबको लाए पास।",

  "अबीर, गुलाल और रंगों की ठंडी हवा,\nखुशियों का आलम है, हर कोई गा रहा है गाना नया।\nमस्ती में नाचे सारा जहान, होली का जादू है सबसे महान।",

  "खुशियों के रंग बिखेर दो, होली का आनंद ले लो,\nबुरा ना मानो, बस रंगों में खो जाओ,\nआज नहीं कोई रोक-टोक, बस प्यार के रंग चढ़ने दो।",

  "रंगों के इस खेल में हर कोई खो जाए,\nहर ग़म और शिकवे मिट जाएं।\nमिलकर बनाएं इस त्यौहार को खास,\nखुशियों से भर जाए हर इंसान।",

  "गली-गली में रंग है छाया,\nहर दिल ने होली का रंग अपनाया।\nढोल की थाप पर नाच रही मस्ती,\nरंगों में घुल गई हर बस्ती।",

  "भांग के नशे में मत हो जाओ गुम,\nरंग डालने के चक्कर में ना हो जाओ तुम गुम।\nगुझिया ज्यादा खाओगे तो पेट बिगड़ जाएगा,\nफिर रंग खेलने का मौका हाथ से निकल जाएगा।",

  "रंग लगाकर कोई भागे, तो उसको पकड़ लो,\nगुझिया खाने से इंकार करे, तो उसको रंग में डुबो दो।\nहोली में ना कोई बुरा मानता, ना कोई रंग से बच पाता।",

  "रंगों में जो ना भीगे, उसे पकड़-पकड़ कर रंग दो,\nजो गुझिया से बचे, उसके मुंह में ठूंस-ठूंस कर भर दो।",

  "बुरा ना मानो होली है,\nआज तो रंग लगाकर छोड़ेंगे नहीं।\nगुझिया खिलाकर, ठंडाई पिलाकर,\nसबको होली का दीवाना बना देंगे।",

  "कोई बचने की कोशिश करेगा, तो हम दौड़कर पकड़ेंगे,\nजो ज्यादा नखरे करेगा, उसे भांग पिला देंगे।",
]

export default function HoliSurprisePage() {
  const { id } = useParams()
  const [greetingData, setGreetingData] = useState<GreetingData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [animationStarted, setAnimationStarted] = useState(false)
  const [showSurprise, setShowSurprise] = useState(false)
  const [selectedShayari] = useState(() => holiShayaris[Math.floor(Math.random() * holiShayaris.length)])
  const confettiCanvasRef = useRef<HTMLCanvasElement>(null)
  const { toast } = useToast()

  // Load the greeting data
  useEffect(() => {
    try {
      const data = localStorage.getItem(`holi-surprise-${id}`)
      if (data) {
        setGreetingData(JSON.parse(data))
      } else {
        setError("Surprise not found. It may have expired or been removed.")
      }
    } catch (err) {
      setError("Error loading the Holi surprise.")
    } finally {
      setLoading(false)
    }
  }, [id])

  // Function to create a color burst effect
  const createColorBurst = (x: number, y: number, colors: string[]) => {
    confetti({
      particleCount: 150,
      spread: 100,
      origin: { x, y },
      colors: colors,
      disableForReducedMotion: true,
      shapes: ["circle", "square"],
      ticks: 200,
    })
  }

  // Function to create a pichkari spray effect
  const createPichkariSpray = (startX: number, startY: number, endX: number, endY: number, color: string) => {
    const particleCount = 50
    const angle = Math.atan2(endY - startY, endX - startX)
    const velocity = 0.7

    confetti({
      particleCount,
      angle: angle * (180 / Math.PI),
      spread: 20,
      startVelocity: velocity * 40,
      decay: 0.93,
      gravity: 0.3,
      drift: 0,
      ticks: 300,
      origin: { x: startX, y: startY },
      colors: [color],
      shapes: ["circle"],
      scalar: 1.2,
    })
  }

  // Function to start the animation sequence
  const startAnimation = () => {
    setShowSurprise(true)
    setAnimationStarted(true)

    // Initial burst in the center
    setTimeout(() => {
      createColorBurst(0.5, 0.5, holiColors)
    }, 500)

    // Random color bursts
    for (let i = 0; i < 12; i++) {
      setTimeout(
        () => {
          const x = 0.1 + Math.random() * 0.8
          const y = 0.1 + Math.random() * 0.8
          createColorBurst(x, y, [holiColors[i % holiColors.length]])
        },
        1000 + i * 500,
      )
    }

    // Pichkari sprays from corners
    const spraySequence = [
      { start: { x: 0.1, y: 0.1 }, end: { x: 0.5, y: 0.5 }, color: holiColors[0] },
      { start: { x: 0.9, y: 0.1 }, end: { x: 0.5, y: 0.5 }, color: holiColors[1] },
      { start: { x: 0.1, y: 0.9 }, end: { x: 0.5, y: 0.5 }, color: holiColors[2] },
      { start: { x: 0.9, y: 0.9 }, end: { x: 0.5, y: 0.5 }, color: holiColors[3] },
      { start: { x: 0.5, y: 0.1 }, end: { x: 0.5, y: 0.9 }, color: holiColors[4] },
      { start: { x: 0.1, y: 0.5 }, end: { x: 0.9, y: 0.5 }, color: holiColors[5] },
    ]

    spraySequence.forEach(({ start, end, color }, index) => {
      setTimeout(
        () => {
          createPichkariSpray(start.x, start.y, end.x, end.y, color)
        },
        2000 + index * 400,
      )
    })

    // Final celebration burst
    setTimeout(() => {
      createColorBurst(0.3, 0.5, holiColors)
      createColorBurst(0.7, 0.5, holiColors)
    }, 5000)
  }

  // Function to share on WhatsApp
  const shareOnWhatsApp = () => {
    const text = encodeURIComponent(
      `${greetingData?.sender || "Someone"} sent you a colorful Holi surprise! 🎨✨\n\nClick to see: ${window.location.href}`,
    )
    window.open(`https://wa.me/?text=${text}`, "_blank")
  }

  // Function to share on Facebook
  const shareOnFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`, "_blank")
  }

  // If still loading, show a loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-violet-500 to-pink-500">
        <div className="text-white text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-white"></div>
          <p className="mt-4 text-xl">Loading your Holi surprise...</p>
        </div>
      </div>
    )
  }

  // If there was an error, show an error message
  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-violet-500 to-pink-500">
        <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full text-center">
          <h1 className="text-2xl font-bold text-violet-600 mb-4">Oops!</h1>
          <p className="text-gray-700 mb-6">{error}</p>
          <Link href="/">
            <Button className="bg-violet-500 hover:bg-violet-600 text-white">
              <Home className="mr-2 h-4 w-4" />
              Go Home
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden bg-gradient-to-r from-violet-500 to-pink-500">
      {/* Canvas for confetti */}
      <canvas ref={confettiCanvasRef} className="fixed inset-0 w-full h-full pointer-events-none z-10"></canvas>

      {!showSurprise ? (
        <div className="bg-white/90 backdrop-blur-sm p-8 rounded-lg shadow-lg max-w-md w-full text-center animate-pulse">
          <h2 className="text-2xl font-bold text-violet-600 mb-4">Holi Surprise!</h2>
          <p className="text-gray-700 mb-6">
            Someone has sent you a colorful Holi greeting! Click to reveal your surprise.
          </p>
          <Button size="lg" onClick={startAnimation} className="bg-violet-500 hover:bg-violet-600 text-white w-full">
            <Sparkles className="mr-2 h-5 w-5" />
            Open Your Surprise
          </Button>
        </div>
      ) : (
        <div className="relative z-20 text-center px-4 animate-fade-in">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 animate-bounce">Happy Holi! 🎨</h1>

          <div className="bg-white/90 backdrop-blur-sm p-6 rounded-lg shadow-lg max-w-md mx-auto mb-8">
            <p className="text-xl md:text-2xl text-violet-600 font-medium mb-4">{greetingData?.message}</p>
            <p className="text-gray-500 text-sm">From: {greetingData?.sender}</p>
          </div>

          <div className="bg-white/80 backdrop-blur-sm p-6 rounded-lg shadow-lg max-w-md mx-auto mb-8">
            <p className="text-xl md:text-2xl text-violet-600 whitespace-pre-line font-medium italic">
              {selectedShayari}
            </p>
          </div>

          <div className="flex flex-wrap gap-4 justify-center">
            <Button onClick={startAnimation} className="bg-yellow-500 hover:bg-yellow-600 text-white">
              <Sparkles className="mr-2 h-4 w-4" />
              More Colors!
            </Button>

            <Button onClick={shareOnWhatsApp} className="bg-green-500 hover:bg-green-600 text-white">
              <Send className="mr-2 h-4 w-4" />
              Share on WhatsApp
            </Button>

            <Button onClick={shareOnFacebook} className="bg-blue-600 hover:bg-blue-700 text-white">
              <Facebook className="mr-2 h-4 w-4" />
              Share on Facebook
            </Button>

            <Link href="/">
              <Button variant="outline" className="bg-white hover:bg-gray-100 text-violet-600 border-violet-200">
                <Home className="mr-2 h-4 w-4" />
                Home
              </Button>
            </Link>
          </div>
        </div>
      )}

      {/* Animated color dots */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {holiColors.map((color, index) => (
          <div
            key={index}
            className="absolute rounded-full animate-float-color"
            style={{
              backgroundColor: color,
              width: `${Math.random() * 30 + 10}px`,
              height: `${Math.random() * 30 + 10}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.7,
              animationDelay: `${index * 0.2}s`,
              animationDuration: `${Math.random() * 10 + 10}s`,
            }}
          ></div>
        ))}
      </div>

      <Toaster />
    </div>
  )
}

