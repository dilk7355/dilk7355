import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import FloatingHearts from "@/components/floating-hearts"

export default function TermsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-pink-200 to-pink-300 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <Card className="max-w-3xl mx-auto border-pink-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-pink-600">
              Terms of Service for TrueLoveCalculator.fun
            </CardTitle>
          </CardHeader>
          <CardContent className="prose prose-pink max-w-none">
            <p>
              By accessing and using TrueLoveCalculator.fun, you agree to abide by the following terms and conditions.
            </p>

            <h3>1. Use of the Website:</h3>
            <p>
              You may only use our website for lawful purposes and in accordance with our terms. You are responsible for
              ensuring that any material you upload or post does not violate any law or rights of third parties.
            </p>

            <h3>2. Limitation of Liability:</h3>
            <p>
              TrueLoveCalculator.fun is not responsible for any loss or damage arising from the use of this website. The
              love calculator results are for entertainment purposes only and we do not guarantee accuracy.
            </p>

            <h3>3. Changes to Services:</h3>
            <p>We may modify or discontinue certain services on our website at any time without prior notice.</p>

            <h3>4. Governing Law:</h3>
            <p>
              These terms will be governed by the laws of the jurisdiction where TrueLoveCalculator.fun is hosted. For
              any issues or questions, feel free to reach out to us.
            </p>
          </CardContent>
        </Card>
      </main>
      <SiteFooter />
    </div>
  )
}

