"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Zap, Sparkles } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

export default function LoveFortuneTellerPage() {
  const [name, setName] = useState("")
  const [birthdate, setBirthdate] = useState("")
  const [fortune, setFortune] = useState<null | {
    prediction: string
    loveDate: string
    luckyColor: string
    advice: string
  }>(null)
  const [isReading, setIsReading] = useState(false)
  const { toast } = useToast()

  // Fortune prediction templates
  const predictions = [
    "Love is coming your way very soon! Someone you already know will reveal their feelings for you.",
    "Your soulmate is closer than you think. Pay attention to someone who makes you laugh.",
    "A passionate romance is on the horizon. Be open to meeting new people in unexpected places.",
    "Your next relationship will teach you important lessons about yourself and what you truly need.",
    "Someone from your past may reenter your life with romantic intentions. Be discerning about their motives.",
    "A chance encounter will lead to a deep connection. Stay alert in social gatherings.",
    "Your perfect match will share an unusual hobby or interest with you. Pursue your passions!",
    "Love will find you when you focus on self-growth and happiness. Your positive energy will attract the right person.",
    "A friendship will blossom into something more meaningful. Look closely at your inner circle.",
    "An unexpected trip or journey will lead you to someone special. Say yes to new adventures!",
  ]

  // Love advice templates
  const advice = [
    "Open your heart to new possibilities. The universe rewards those who are receptive to love.",
    "Communication will be key in your next relationship. Express your feelings honestly and listen actively.",
    "Trust your intuition when meeting new people. Your inner voice knows who is right for you.",
    "Let go of past heartbreaks to make room for new love. Healing is necessary before moving forward.",
    "Don't rush into commitment. Take time to truly know someone before giving your heart away.",
    "Be authentic in your search for love. The right person will appreciate the real you.",
    "Balance giving and receiving in relationships. Healthy love requires mutual effort.",
    "Look beyond physical attraction. Lasting connections are built on shared values and emotional compatibility.",
    "Patience will lead you to the right person. Don't settle out of fear of being alone.",
    "Self-love attracts healthy relationships. Nurture yourself first, and the right love will follow.",
  ]

  // Lucky colors
  const luckyColors = [
    "Red",
    "Pink",
    "Purple",
    "Blue",
    "Green",
    "Yellow",
    "Orange",
    "Turquoise",
    "Lavender",
    "Rose Gold",
  ]

  const readFortune = () => {
    if (!name) {
      toast({
        title: "Name required",
        description: "Please enter your name to read your love fortune",
        variant: "destructive",
      })
      return
    }

    setIsReading(true)
    setTimeout(() => {
      // Generate a "random" but deterministic result based on name and birthdate
      const nameSum = name.split("").reduce((sum, char) => sum + char.charCodeAt(0), 0)
      const birthdateValue = birthdate ? new Date(birthdate).getTime() : 0
      const combinedValue = nameSum + birthdateValue

      // Select prediction, advice and lucky color based on the combined value
      const predictionIndex = combinedValue % predictions.length
      const adviceIndex = (combinedValue + 3) % advice.length
      const colorIndex = (combinedValue + 7) % luckyColors.length

      // Generate a "love date" (a date within the next 3 months)
      const today = new Date()
      const daysToAdd = (combinedValue % 90) + 1 // 1-90 days
      const loveDate = new Date(today)
      loveDate.setDate(today.getDate() + daysToAdd)

      const formattedDate = loveDate.toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      })

      setFortune({
        prediction: predictions[predictionIndex],
        loveDate: formattedDate,
        luckyColor: luckyColors[colorIndex],
        advice: advice[adviceIndex],
      })

      setIsReading(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-amber-200 to-purple-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-amber-600 mb-6 text-center">Love Fortune Teller</h1>

        <Card className="max-w-md mx-auto border-amber-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-amber-600 flex items-center justify-center gap-2">
              <Zap className="h-5 w-5 text-amber-500" />
              Love Fortune Teller
            </CardTitle>
            <CardDescription>Get fun predictions about your love life</CardDescription>
          </CardHeader>

          <CardContent>
            {!fortune ? (
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Your Name</Label>
                  <Input
                    id="name"
                    placeholder="Enter your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="border-amber-200 focus:border-amber-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="birthdate">Your Birthdate (Optional)</Label>
                  <Input
                    id="birthdate"
                    type="date"
                    value={birthdate}
                    onChange={(e) => setBirthdate(e.target.value)}
                    className="border-amber-200 focus:border-amber-400"
                  />
                </div>
              </div>
            ) : (
              <div className="py-6 text-center space-y-6">
                <div className="relative mx-auto w-24 h-24 flex items-center justify-center mb-4">
                  <div className="absolute inset-0 rounded-full bg-amber-100 animate-pulse"></div>
                  <Sparkles className="relative z-10 h-12 w-12 text-amber-500" />
                </div>
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-amber-600">Your Love Fortune</h3>

                  <div className="bg-amber-50 p-4 rounded-lg border border-amber-200 text-left">
                    <p className="text-amber-800 mb-3">{fortune.prediction}</p>
                    <div className="space-y-2 mt-4">
                      <p className="text-sm text-amber-700">
                        <span className="font-bold">Important Date:</span> {fortune.loveDate}
                      </p>
                      <p className="text-sm text-amber-700">
                        <span className="font-bold">Lucky Color:</span> {fortune.luckyColor}
                      </p>
                    </div>
                  </div>

                  <div className="bg-purple-50 p-4 rounded-lg border border-purple-200 text-left">
                    <p className="font-medium text-purple-700 mb-1">Love Advice:</p>
                    <p className="text-purple-600">{fortune.advice}</p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>

          <CardFooter>
            <Button
              onClick={fortune ? () => setFortune(null) : readFortune}
              className={`w-full ${
                !fortune
                  ? "bg-amber-500 hover:bg-amber-600 text-white"
                  : "bg-amber-100 hover:bg-amber-200 text-amber-600"
              }`}
              disabled={isReading}
            >
              {isReading ? (
                <>
                  Reading your fortune<span className="animate-pulse">...</span>
                </>
              ) : fortune ? (
                <>Read Another Fortune</>
              ) : (
                <>Reveal My Love Fortune</>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}

