import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, Sparkles, Star, Info } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import FloatingHearts from "@/components/floating-hearts"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-pink-200 to-pink-300 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-pink-600 mb-6 text-center">About TrueLoveCalculator.fun</h1>

        <Card className="max-w-3xl mx-auto border-pink-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-pink-600 flex items-center justify-center gap-2">
              <Heart className="h-6 w-6 text-red-500 fill-red-500" />
              Our Love Story
              <Heart className="h-6 w-6 text-red-500 fill-red-500" />
            </CardTitle>
          </CardHeader>
          <CardContent className="prose prose-pink max-w-none space-y-6">
            <div className="flex items-start gap-3">
              <Info className="h-6 w-6 text-pink-500 mt-1 flex-shrink-0" />
              <div>
                <h3 className="text-xl font-medium text-pink-600 mt-0">What is TrueLoveCalculator.fun?</h3>
                <p>
                  TrueLoveCalculator.fun is a fun and entertaining platform dedicated to all things love and
                  relationships. We offer a variety of playful tools and calculators designed to bring joy, laughter,
                  and sometimes even insight into your romantic life.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Sparkles className="h-6 w-6 text-yellow-500 mt-1 flex-shrink-0" />
              <div>
                <h3 className="text-xl font-medium text-pink-600 mt-0">Our Mission</h3>
                <p>
                  Our mission is simple: to create a delightful experience that brings smiles to people's faces. While
                  our tools are primarily for entertainment, we believe that sometimes a little fun can spark meaningful
                  conversations and connections between people.
                </p>
                <p>
                  We're passionate about creating engaging, user-friendly tools that anyone can enjoy, whether you're
                  single, in a relationship, or just curious about the mysteries of love.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Star className="h-6 w-6 text-amber-500 mt-1 flex-shrink-0" />
              <div>
                <h3 className="text-xl font-medium text-pink-600 mt-0">Our Features</h3>
                <p>TrueLoveCalculator.fun offers a wide range of love-themed tools, including:</p>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
                  <li>Love Compatibility Calculator</li>
                  <li>Zodiac Match Finder</li>
                  <li>Love Story Generator</li>
                  <li>Future Love Story Predictor</li>
                  <li>Secret Admirer Detector</li>
                  <li>Love Song Recommender</li>
                  <li>Photo Love Scanner</li>
                  <li>Voice Love Calculator</li>
                  <li>Love Proposal Generator</li>
                  <li>Relationship Expiry Calculator</li>
                  <li>Life Lucky Number Calculator</li>
                  <li>And many more!</li>
                </ul>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Heart className="h-6 w-6 text-red-500 fill-red-500 mt-1 flex-shrink-0" />
              <div>
                <h3 className="text-xl font-medium text-pink-600 mt-0">Important Note</h3>
                <p>
                  While we put a lot of love into creating these tools, please remember that they are designed for
                  entertainment purposes only. Real relationships are complex and unique, built on communication, trust,
                  respect, and understanding.
                </p>
                <p>
                  We hope our tools bring you joy and perhaps a few laughs, but we encourage you to approach matters of
                  the heart with thoughtfulness and care.
                </p>
              </div>
            </div>

            <div className="mt-8 text-center">
              <Link href="/tools">
                <Button className="bg-pink-500 hover:bg-pink-600 text-white">
                  <Sparkles className="mr-2 h-4 w-4" /> Explore Our Love Tools
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </main>
      <SiteFooter />
    </div>
  )
}

